/*
  Instead of one big configuration file managing multiple tasks,
  each task is splitted to its own file under 'gulptasks' directory.

  Any gulp task file in 'gulptasks' directory get included and can be
  invoked via the task name as per normal. e.g. gulp clean
*/

var gulp = require('gulp');
var requireDir = require('require-dir');
requireDir('./gulptasks');

gulp.task('test', ['unit-test', 'browser-test']);
gulp.task('test-build', ['bundle-core', 'bundle-test']);
gulp.task('build', ['minify']);

// default task
gulp.task('default', ['resources', 'lint', 'coverage', 'build']);
