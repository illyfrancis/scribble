var gulp = require('gulp');
var mochaPhantomJS = require('gulp-mocha-phantomjs');

var config = require('./config');
var paths = config.paths;

gulp.task('browser-test', ['resources', 'test-build'], function () {
  var stream = gulp.src(paths.target.dir + 'mocha.html')
    .pipe(mochaPhantomJS({
      phantomjs: {
        hooks: 'mocha-phantomjs-istanbul',
        coverageFile: paths.coverage.files.browserTest
      },
      reporter: 'spec'
    }))
    .on('error', config.handleError);

  return stream;
});
