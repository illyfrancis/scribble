var clean = require('gulp-clean');
var gulp = require('gulp');

var paths = require('./config').paths;

gulp.task('clean', function () {
  return gulp.src(paths.target.dir, {read: false})
    .pipe(clean());
});
