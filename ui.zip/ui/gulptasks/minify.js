var gulp = require('gulp');
var gulpif = require('gulp-if');
var uglify = require('gulp-uglify');

var config = require('./config');
var paths = config.paths;

gulp.task('minify', ['bundle'], function () {
  var stream = gulp.src(paths.target.app)
    .pipe(gulpif(config.isProduction, uglify()))
    .pipe(gulp.dest(paths.target.dir));

  return stream;
});
