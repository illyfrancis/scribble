var args = require('yargs').argv;
var gutil = require('gulp-util');

var appjsName = 'app.js';

var config = {
  // set environment variable TARGET_ENVIRONMENT to PRODUCTION to enable production mode
  isProduction: process.env.TARGET_ENVIRONMENT === 'PRODUCTION',

  appjs: appjsName,

  brands: ['bbh', 'mugc', 'mutu', 'sebn'],

  paths: {
    main: {
      app: './src/main/js/' + appjsName,
      js: './src/main/js/**/*.js',
      templates: './src/main/js/**/*.html',
      resources: './src/main/resources/**/*.*'
    },
    test: {
      js: './src/test/js/**/*.js',
      jsnode: './src/test/jsnode/**/*.js',
      resources: './src/test/resources/**/*.*'
    },
    coverage: {
      dir: './target/coverage/',
      files: {
        unitTest: './target/coverage/testsCoverage.json',
        browserTest: './target/coverage/browserTestCoverage.json'
      }
    },
    target: {
      dir: './target/',
      app: './target/' + appjsName
    }
  },

  // gulp {task} --exitOnError
  handleError: function (err) {
    gutil.log('An error occured: ' + err);
    if (args.exitOnError) {
      process.exit(1);
    } else {
      this.emit('end');
    }
  }
};

module.exports = config;
