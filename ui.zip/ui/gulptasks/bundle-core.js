var browserify = require('browserify');
var browserifyIstanbul = require('browserify-istanbul');
var glob = require('glob');
var gulp = require('gulp');
var hbsfy = require('hbsfy').configure({extensions: ['html']});
var source = require('vinyl-source-stream');
var templateclean = require('./templateclean');

var paths = require('./config').paths;

gulp.task('bundle-core', function () {
  var b = browserify();
  glob.sync(paths.main.js).forEach(function (file) {
    b.add(file);
    b.require(file, {expose: '.'});
  });

  var stream = b
    .transform(templateclean)
    .transform(hbsfy)
    .transform(browserifyIstanbul({ignore: ['**/lib/**/*.js', '**/*.html'], defaultIgnore: true}))
    .bundle()
    .pipe(source('core.js'))
    .pipe(gulp.dest(paths.target.dir));

  return stream;
});
