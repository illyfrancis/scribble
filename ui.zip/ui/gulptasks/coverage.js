var gulp = require('gulp');
var istanbulReport = require('gulp-istanbul-report');

var config = require('./config');
var paths = config.paths;

gulp.task('coverage', ['test'], function () {
  var stream = gulp.src([paths.coverage.files.unitTest, paths.coverage.files.browserTest])
    .pipe(istanbulReport({
      dir: paths.coverage.dir,
      reporters: ['html', 'cobertura', 'text-summary']
    }))
    .on('error', config.handleError);

  return stream;
});
