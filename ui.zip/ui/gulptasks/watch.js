var gulp = require('gulp');
var paths = require('./config').paths;

gulp.task('watch', function () {
  gulp.watch(
    ['.jshintrc', 'gulpfile.js', paths.main.js, paths.main.templates, paths.test.js, './src/main/resources/**/*.less'],
    ['resources', 'lint', 'test', 'build']);
});
