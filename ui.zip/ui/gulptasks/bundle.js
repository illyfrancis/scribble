var browserify = require('browserify');
var gulp = require('gulp');
var hbsfy = require('hbsfy').configure({extensions: ['html']});
var source = require('vinyl-source-stream');
var templateclean = require('./templateclean');

var config = require('./config');
var paths = config.paths;

gulp.task('bundle', function () {
  var b = browserify();
  var stream = b.add(paths.main.app)
    .transform(templateclean)
  	.transform(hbsfy)
    .bundle({debug: ! config.isProduction})
    .on('error', config.handleError)
    .pipe(source(config.appjs))
    .pipe(gulp.dest(paths.target.dir));

  return stream;
});
