var browserify = require('browserify');
var glob = require('glob');
var gulp = require('gulp');
var source = require('vinyl-source-stream');

var paths = require('./config').paths;

gulp.task('bundle-test', function () {
  var b = browserify();
  glob.sync(paths.main.js).forEach(function (file) {
    b.external(file);
  });
  glob.sync(paths.test.js).forEach(function (file) {
    b.add(file);
  });
  var stream = b.bundle()
    .pipe(source('tests.js'))
    .pipe(gulp.dest(paths.target.dir));

  return stream;
});
