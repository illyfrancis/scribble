var gulp = require('gulp');
var paths = require('./config').paths;

gulp.task('resources', ['less'], function () {
  return gulp.src([
      '!./src/main/resources/less/*.less',
      paths.main.resources,
      paths.test.resources
    ])
    .pipe(gulp.dest(paths.target.dir));
});
