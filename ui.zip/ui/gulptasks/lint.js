var gulp = require('gulp');
var jshint = require('gulp-jshint');

var paths = require('./config').paths;

gulp.task('lint', function () {
  var stream = gulp.src(['gulpfile.js', paths.main.js, paths.test.js, paths.test.jsnode])
    .pipe(jshint())
    .pipe(jshint.reporter('jshint-stylish'));

  return stream;
});
