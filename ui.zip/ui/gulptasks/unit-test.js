var fs = require('fs');
var gulp = require('gulp');
var istanbul = require('gulp-istanbul');
var mkdirp = require('mkdirp');
var mocha = require('gulp-mocha');
var through = require('through');
var Q = require('q');

var config = require('./config');
var paths = config.paths;

var testsCoverageVariable = 'testsCoverageVar';

gulp.task('unit-test', function () {
  var deferred = Q.defer();

  gulp.src(paths.main.js)
    .pipe(istanbul({
      includeUntested: true,
      coverageVariable: testsCoverageVariable
    }))
    .pipe(istanbul.hookRequire()) // Force `require` to return covered files
    .on('finish', function () {
      gulp.src(paths.test.jsnode, {read: false})
        .pipe(mocha({
          reporter: 'tap'
        }))
        .on('error', config.handleError)
        .pipe(through(function write(data) { // Collect coverage information and store it in file
            this.queue(data);
          },
          function end() {
            mkdirp.sync(paths.coverage.dir, config.handleError);

            var json = JSON.stringify(global[testsCoverageVariable]);
            fs.writeFileSync(paths.coverage.files.unitTest, json);

            this.resume();
            deferred.resolve();
          }))
        .on('error', config.handleError);
    });

  return deferred.promise;
});
