var htmlclean = require('htmlclean');
var through = require('through');

var templateclean = function (file) {
  if (file.split('.').pop() !== 'html') {
    return through();
  }

  var buffer = '';

  return through(function (chunk) {
      buffer += chunk.toString();
    },

    function () {
      var html = htmlclean(buffer);
      this.queue(html);
      this.queue(null);
    });
}

module.exports = templateclean;
