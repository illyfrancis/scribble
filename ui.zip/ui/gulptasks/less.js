var each = require('foreach');
var gulp = require('gulp');
var gulpif = require('gulp-if');
var less = require('gulp-less');
var minifycss = require('gulp-minify-css');
var prefix = require('gulp-autoprefixer');
var rename = require('gulp-rename');

var config = require('./config');

gulp.task('less', function () {
  each(config.brands, function (brandName) {
    return gulp.src([
        './src/main/resources/less/dashboard.less',
        './src/main/resources/less/dashboard-ie.less'
      ])
      .pipe(less({
        strictMath: true,
        globalVars: {
          brand: brandName,
        },
      }))
      .pipe(prefix({
        browsers: [
          'Android 2.3',
          'Android >= 4',
          'Chrome >= 20',
          'Firefox >= 24', // Firefox 24 is the latest ESR
          'Explorer >= 8',
          'iOS >= 6',
          'Opera >= 12',
          'Safari >= 6'
        ]
      }))
      .pipe(gulpif(config.isProduction, minifycss({
        keepSpecialComments: 0
      })))
      .pipe(rename({prefix: brandName + '-'}))
      .pipe(gulp.dest('./target/css'));
  });
});
