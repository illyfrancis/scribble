# JavaScript plugins / dependencies

## Typeahead

### Source

* https://github.com/twitter/typeahead.js (0.10.2)
* no less file provided

### Less 

* https://github.com/hyspace/typeahead.js-bootstrap3.less

## Bootstrap select

### Source

* bootstrap-select v1.5.4
* http://silviomoreto.github.io/bootstrap-select/
* does not provide its own less file

## Bootstrap datepicker

### Source

* bootstrap-datepicker.js (1.3.0)
* https://github.com/eternicode/bootstrap-datepicker/

### Less

* https://github.com/eternicode/bootstrap-datepicker/tree/master/less

### Notes

Version of this plug-in was upgraded from `1.3.0` to the most recent one from [master repository](https://github.com/eternicode/bootstrap-datepicker/). It fixed issues with IE 8 (clear button not working, on some occasions selecting multiple dates), but introduced a new issue specific for Chrome browser. Because of changed `z-index` calculation, on Chrome date picker appeared below grayed-out background of modal filter dialog. To fix that, code responsible for `z-index` calculation from version 1.3.0 was manually broguht to the most recent version used in the Dashboard. In case of update of datepicker plug-in in the future, this excercise will have to be repeated, unless the updated version contains fix for `z-index` calculation.

Working `z-index` calculation code (lines 553-556 in version `1.3.0`):

```js
  var parentZIndexes = this.element.parents().map(function () {
    return parseInt($(this).css('z-index')) || 0;
  });
  var zIndex = Math.max.apply(Math, Array.prototype.slice.apply(parentZIndexes)) + 10;
```