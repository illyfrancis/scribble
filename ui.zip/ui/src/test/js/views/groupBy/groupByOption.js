/*global sinon*/
var Criteria = require('../../../../../src/main/js/collections/criteria');
var Criterion = require('../../../../../src/main/js/models/criteria/criterion');
var GroupBy = require('../../../../../src/main/js/views/groupBy/groupBy');
var User = require('../../../../../src/main/js/models/user');
var repository = require('../../../../../src/main/js/repository');

var assert = require('assert');

describe('GroupByOption View', function () {

  var xhr, requests, repositoryStub;

  var testUser = new User({
    'id': 'A012345',
    'roles': ['ADMIN']
  });

  beforeEach(function () {
    xhr = sinon.useFakeXMLHttpRequest();
    requests = [];
    xhr.onCreate = function (req) {
      requests.push(req);
    };

    repositoryStub = sinon.stub(repository, "user");
    repositoryStub.returns(testUser);

  });

  afterEach(function () {
    xhr.restore();
    repositoryStub.restore();
  });

  var createGroupByWithOption = function () {
    var criterion = new Criterion({
      id: 'reportName',
      title: 'Report name',
      isSortable: true
    });

    var testCriteria = new Criteria(criterion);

    var groupBy = new GroupBy({
      collection: testCriteria,
      user: testUser,
    });

    groupBy.$el.html('<ul class="dropdown-menu"></ul>');
    groupBy.render();

    return groupBy;
  };

  var groupByHasSelectedOption = function (groupBy) {
    return groupBy.$el.has('li:first a > span').length === 1;
  };

  it('adds selection mark after clicking on option', function () {

    var groupByWithOption = createGroupByWithOption();

    groupByWithOption.$('li:first').click();

    // 2 POST requests are made after toggling grouping option 
    assert.equal(2, requests.length);
    
    assert.equal('POST', requests[0].method);
    assert(requests[0].url, './api/settings/filters');
    assert.equal('POST', requests[1].method);
    assert(requests[1].url, './api/schedules/clients');

    assert(groupByHasSelectedOption(groupByWithOption));

  });

  it('removes selection mark after clicking second time on option', function () {

    var groupByWithOption = createGroupByWithOption();

    groupByWithOption.$('li:first').click();
    groupByWithOption.$('li:first').click();

    // 2 more POST requests after second click
    assert.equal(4, requests.length);

    assert.equal('POST', requests[2].method);
    assert(requests[2].url, './api/settings/filters');
    assert.equal('POST', requests[3].method);
    assert(requests[3].url, './api/schedules/clients');

    assert.equal(groupByHasSelectedOption(groupByWithOption), false);

  });

});
