var Criteria = require('../../../../../src/main/js/collections/criteria');
var Criterion = require('../../../../../src/main/js/models/criteria/criterion');
var GroupBy = require('../../../../../src/main/js/views/groupBy/groupBy');
var User = require('../../../../../src/main/js/models/user');

var assert = require('assert');

describe('GroupBy View', function () {


  var createGroupByClientFor = function (role) {

    var testCriterion = new Criterion({
      id: 'clients',
      title: 'Client',
      isSortable: true
    });

    return createGroupByCriterionFor(role, testCriterion);
  };

  var createGroupByCriterionFor = function (role, criterion) {

    var testUser = new User({
      'id': 'A012345',
      'roles': [role]
    });

    var testCriteria = new Criteria(criterion);

    var testgroupBy = new GroupBy({
      collection: testCriteria,
      user: testUser,
    });

    testgroupBy.$el.html('<ul class="dropdown-menu"></ul>');

    return testgroupBy;
  };


  var containsOption = function (groupBy, optionName) {
    return groupBy.$el.has('a:contains(' + optionName + ')').length === 1;
  };

  var assertClientOptionDisplayed = function (role) {

    var groupBy = createGroupByClientFor(role);

    groupBy.render();

    assert(containsOption(groupBy, 'Client'));
  };

  it('renders client option if Report Owner', function () {

    assertClientOptionDisplayed('REPORT_OWNER');
  });

  it('renders client option if Service Delivery', function () {

    assertClientOptionDisplayed('SERV_DELIVER');
  });

  it('renders client option if Admin', function () {

    assertClientOptionDisplayed('ADMIN');
  });

  it('doesnt render option which is not sortable', function () {

    var sortableCriterion = new Criterion({
      id: 'frequency',
      title: 'Frequency',
      isSortable: false
    });

    var groupBy = createGroupByCriterionFor('ADMIN', sortableCriterion);

    groupBy.render();

    assert.equal(containsOption(groupBy, 'Frequency'), false);
  });

  it('renders sortable option', function () {

    var notSortableCriterion = new Criterion({
      id: 'reportName',
      title: 'Report name',
      isSortable: true
    });

    var groupBy = createGroupByCriterionFor('ADMIN', notSortableCriterion);

    groupBy.render();

    assert(containsOption(groupBy, 'Report name'));
  });

});
