var moment = require('moment-timezone');
var ScheduleItem = require('../../../../../src/main/js/views/schedules/scheduleItem');
var Schedule = require('../../../../../src/main/js/models/schedule');
var User = require('../../../../../src/main/js/models/user');

var assert = require('assert');

describe('ScheduleItem View', function () {

  var scheduleItem;
  var deafultLastExecutionTime = '2014-01-04T06:30:15Z';
  var defaultReportExpiryTime = '2014-12-05T03:40:15Z';
  var deafultLastExecutionTimeDST = '2014-06-04T06:30:15Z';
  var defaultReportExpiryTimeDST = '2015-06-30T23:15:20Z';

  beforeEach(function () {

    var testUser = new User({
      'id': 'A012345',
      'roles': ['REPORT_OWNER'],
      'timezone': 'US/Eastern'
    });

    scheduleItem = new ScheduleItem({
      user: testUser,
      model: new Schedule()
    });
  });

  describe('maps date property to', function () {

    it('valid moment when property is valid date', function () {

      scheduleItem.model.set('lastExecution', deafultLastExecutionTime);
      var moment = scheduleItem.mapPropertyToMoment('lastExecution');
      assert.equal(moment.isValid(), true);
    });

    it('invalid moment when property is invalid date', function () {

      scheduleItem.model.set('lastExecution', '2014-00-04T06:30:15Z');
      var moment = scheduleItem.mapPropertyToMoment('lastExecution');
      assert.equal(moment.isValid(), false);
    });

    it('invalid moment when property is null', function () {

      scheduleItem.model.set('lastExecution', null);
      var moment = scheduleItem.mapPropertyToMoment('lastExecution');
      assert.equal(moment.isValid(), false);
    });

    it('invalid moment when property is not a date string', function () {

      scheduleItem.model.set('lastExecution', 'xyz');
      var moment = scheduleItem.mapPropertyToMoment('lastExecution');
      assert.equal(moment.isValid(), false);
    });

    it('invalid moment when property is undefined', function () {

      scheduleItem.model.set('lastExecution', undefined);
      var moment = scheduleItem.mapPropertyToMoment('lastExecution');
      assert.equal(moment.isValid(), false);
    });

  });

  describe('creates display value', function () {

    var lastExecutionPattern = /^(\d+|a(n)?)\s[a-z]+\sago/;

    it('as time from now for last execution time', function () {

      scheduleItem.model.set('lastExecution', deafultLastExecutionTime);
      var actualValue = scheduleItem.mapLastExecution();

      assert(lastExecutionPattern.test(actualValue));

    });

    it('as empty string for invalid last execution time', function () {

      scheduleItem.model.set('lastExecution', 'xyz');
      var actualValue = scheduleItem.mapLastExecution();

      assert.equal(actualValue, '');

    });

    it('as "No expiry" value for empty report expiry time', function () {

      scheduleItem.model.set('reportExpiry', '');
      var expectedValue = 'No expiry';
      var actualValue = scheduleItem.mapReportExpiry();

      assert.equal(actualValue, expectedValue);

    });

    it('as previous day date in MMM Do YYYY format for report expiry time in UTC-0X timezone', function () {

      scheduleItem.model.set('reportExpiry', defaultReportExpiryTime);
      var expectedValue = 'Dec 4th 2014';  //UTC-05
      var actualValue = scheduleItem.mapReportExpiry();

      assert.equal(actualValue, expectedValue);

    });

    it('as next day date in MMM Do YYYY format for report expiry time in UTC+0X timezone', function () {

      scheduleItem.user = new User({'timezone': 'Europe/Amsterdam'}); 
      scheduleItem.model.set('reportExpiry', defaultReportExpiryTimeDST);
      var expectedValue = 'Jul 1st 2015'; //UTC+02 DST
      var actualValue = scheduleItem.mapReportExpiry();

      assert.equal(actualValue, expectedValue);

    });

  });

  describe('displays tooltip', function () {

    var createScheduleItem = function () {

      var testSchedule = new Schedule({
        'lastExecution': deafultLastExecutionTime,
        'reportExpiry': defaultReportExpiryTime
      });

      var testScheduleItem = new ScheduleItem({
        model: testSchedule,
        user: new User({'timezone': 'US/Eastern'}),
      });

      return testScheduleItem;
    };

    it('for last execution as empty string when date is invalid', function () {

      var testScheduleItem = createScheduleItem();
      testScheduleItem.model.set('lastExecution', 'invalid date');

      var tooltipTitle = testScheduleItem.lastExecutionAsTooltip();
      assert.equal(tooltipTitle, '');
    });

    it('for last execution in the expected format when DST date is valid and user has US/Eastern timezone setting', function () {

      var expectedTooltipValue = '04-Jun-2014 2:30:15am'; //UTC-04 (DST) from deafultLastExecutionTimeDST

      var testScheduleItem = createScheduleItem();
      testScheduleItem.model.set('lastExecution', deafultLastExecutionTimeDST);
      var actualTooltipValue = testScheduleItem.lastExecutionAsTooltip();

      assert.equal(actualTooltipValue, expectedTooltipValue);
    });

    it('for last execution in the expected format when standard time date is valid and user has US/Eastern timezone setting', function () {

      var expectedTooltipValue = '04-Jan-2014 1:30:15am'; //UTC-05 from deafultLastExecutionTime

      var testScheduleItem = createScheduleItem();
      var actualTooltipValue = testScheduleItem.lastExecutionAsTooltip();

      assert.equal(actualTooltipValue, expectedTooltipValue);
    });

    it('for last execution in the expected format when DST date is valid and user has Europe/Amsterdam timezone setting', function () {

      var expectedTooltipValue = '04-Jun-2014 8:30:15am'; //UTC+02 (DST) from deafultLastExecutionTimeDST

      var testScheduleItem = createScheduleItem();
      testScheduleItem.model.set('lastExecution', deafultLastExecutionTimeDST);
      testScheduleItem.user = new User({'timezone': 'Europe/Amsterdam'});

      var actualTooltipValue = testScheduleItem.lastExecutionAsTooltip();

      assert.equal(actualTooltipValue, expectedTooltipValue);
    });

    it('for last execution in the expected format when standard time date is valid and user has Europe/Amsterdam timezone setting', function () {

      var expectedTooltipValue = '04-Jan-2014 7:30:15am'; //UTC+01 from deafultLastExecutionTime

      var testScheduleItem = createScheduleItem();
      testScheduleItem.user = new User({'timezone': 'Europe/Amsterdam'});

      var actualTooltipValue = testScheduleItem.lastExecutionAsTooltip();

      assert.equal(actualTooltipValue, expectedTooltipValue);
    });

    it('for report expiry as empty string when date is invalid', function () {

      var testScheduleItem = createScheduleItem();
      testScheduleItem.model.set('reportExpiry', 'invalid date');

      var tooltipTitle = testScheduleItem.reportExpiryAsTooltip();
      assert.equal(tooltipTitle, '');
    });

    it('for report expiry in the expected format when DST date is valid and user has US/Eastern timezone setting', function () {

      var expectedTooltipValue = 'At 7:15:20pm'; // UTC-04 (DST) from defaultReportExpiryTimeDST

      var testScheduleItem = createScheduleItem();
      testScheduleItem.model.set('reportExpiry', defaultReportExpiryTimeDST);
      var actualTooltipValue = testScheduleItem.reportExpiryAsTooltip();

      assert.equal(actualTooltipValue, expectedTooltipValue);
    });

    it('for report expiry in the expected format when standard time date is valid and user has US/Eastern timezone setting', function () {

      var expectedTooltipValue = 'At 10:40:15pm'; // UTC-05 from defaultReportExpiryTime

      var testScheduleItem = createScheduleItem();
      var actualTooltipValue = testScheduleItem.reportExpiryAsTooltip();

      assert.equal(actualTooltipValue, expectedTooltipValue);
    });

    it('for report expiry in the expected format when DST date is valid and user has Europe/Amsterdam timezone setting', function () {

      var expectedTooltipValue = 'At 1:15:20am'; // UTC+02 (DST) from defaultReportExpiryTimeDST

      var testScheduleItem = createScheduleItem();
      testScheduleItem.model.set('reportExpiry', defaultReportExpiryTimeDST);
      testScheduleItem.user = new User({'timezone': 'Europe/Amsterdam'});

      var actualTooltipValue = testScheduleItem.reportExpiryAsTooltip();

      assert.equal(actualTooltipValue, expectedTooltipValue);
    });

    it('for report expiry in the expected format when standard time date is valid and user has Europe/Amsterdam timezone setting', function () {

      var expectedTooltipValue = 'At 4:40:15am'; // UTC+01 from defaultReportExpiryTime

      var testScheduleItem = createScheduleItem();
      testScheduleItem.user = new User({'timezone': 'Europe/Amsterdam'});

      var actualTooltipValue = testScheduleItem.reportExpiryAsTooltip();

      assert.equal(actualTooltipValue, expectedTooltipValue);
    });
  });

  describe('maps upcoming runtime to', function () {

    it('user timezone', function () {

      var upcomingRuntime = '2016-01-04T06:30:15Z';

      var upcominRuntimeUtc = moment.tz(upcomingRuntime, 'YYYY-MM-DDTHH:mm:ssZ', 'UTC');
      var upcomingRuntimeUsEastern = upcominRuntimeUtc.tz('US/Eastern').format('DD-MMM-YYYY h:mma');

      var result = scheduleItem.mapUpcomingRuntime(upcomingRuntime);

      assert.equal(result, upcomingRuntimeUsEastern);
    });

    it('space if empty', function () {

      var upcomingRuntime = '';

      var result = scheduleItem.mapUpcomingRuntime(upcomingRuntime);

      assert.equal(result, ' ');
    });
  });
});
