/*global sinon*/
var Criteria = require('../../../../../src/main/js/collections/criteria');
var ScheduleList = require('../../../../../src/main/js/views/schedules/scheduleList');
var Schedule = require('../../../../../src/main/js/models/schedule');
var Schedules = require('../../../../../src/main/js/collections/schedules');
var User = require('../../../../../src/main/js/models/user');

var assert = require('assert');

describe('ScheduleList View', function () {

  var scheduleList;

  var contains = function (selector) {
    return scheduleList.$el.find(selector).length === 1;
  };

  var containsHeader = function (header) {
    return contains('table > thead > tr > th > div:contains(' + header + ')');
  };

  var containsItem = function (item) {
    return contains('table > tbody > tr > td:contains(' + item + ')');
  };

  beforeEach(function () {

    var testUser = new User({
      'id': 'A012345',
      'roles': ['REPORT_OWNER'],
      'timezone': 'US/Eastern'
    });

    sinon.stub(Schedule.prototype, "formatWeekDays").returns('M, T');

    scheduleList = new ScheduleList({
      user: testUser,
      criteria : new Criteria(),
      collection: new Schedules()
    });
  });

  afterEach(function () {
    Schedule.prototype.formatWeekDays.restore();
  });

  describe('renders', function () {

    it('header columns', function () {

      scheduleList.render();

      assert(containsHeader('Report name'));
      assert(containsHeader('Report category'));
      assert(containsHeader('Report type'));
      assert(containsHeader('Report owner'));
      assert(containsHeader('Created by'));
      assert(containsHeader('Modified by'));
      assert(containsHeader('Frequency'));
      assert(containsHeader('Distribution list'));
      assert(containsHeader('Last execution'));
      assert(containsHeader('Delivery'));
      assert(containsHeader('Client'));
      assert(containsHeader('Report expiry'));
    });

    it('schedule items', function () {

      scheduleList.collection.add(new Schedule({reportName : 'TEST_REPORT_1'}));
      scheduleList.collection.add(new Schedule({reportName : 'TEST_REPORT_2'}));

      scheduleList.render();

      assert(containsItem('TEST_REPORT_1'));
      assert(containsItem('TEST_REPORT_2'));
    });


    it('no schedules found message', function () {

      scheduleList.render();

      assert(containsItem('no schedules found'));
    });

  });
});
