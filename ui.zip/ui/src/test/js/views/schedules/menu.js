var Criteria = require('../../../../../src/main/js/collections/criteria');
var Menu = require('../../../../../src/main/js/views/schedules/menu');
var User = require('../../../../../src/main/js/models/user');

var assert = require('assert');

describe('Menu View', function () {

  var testMenu;

  beforeEach(function () {
    var testUser = new User({
      'id': 'A012345'
    });

    testMenu = new Menu({
      criteria: new Criteria(),
      user: testUser
    });
  });

  it('renders filter button', function () {
    testMenu.render();
    assert(containsElementWithClass(testMenu, '.filters'));
  });

  it('renders group by button', function () {
    testMenu.render();
    assert(containsElementWithClass(testMenu, '.group-by'));
  });

  it('renders search button', function () {
    testMenu.render();
    assert(containsElementWithClass(testMenu, '.search'));
  });

  var containsElementWithClass = function (menu, className) {
    return menu.$el.has(className).length === 1;
  };
});
