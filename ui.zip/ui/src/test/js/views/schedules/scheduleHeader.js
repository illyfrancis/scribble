var Criteria = require('../../../../../src/main/js/collections/criteria');
var Criterion = require('../../../../../src/main/js/models/criteria/criterion');
var ScheduleHeader = require('../../../../../src/main/js/views/schedules/scheduleHeader');
var User = require('../../../../../src/main/js/models/user');

var assert = require('assert');

describe('Schedule Header View', function () {

  var createScheduleHeaderFor = function (role) {

    var testUser = new User({
      'id': 'A012345',
      'roles': [role]
    });

    var testCriterion = new Criterion({
      id: 'clients',
      title: 'Client',
      isSortable: true
    });

    var testCriteria = new Criteria(testCriterion);

    var testScheduleHeader = new ScheduleHeader({
      collection: testCriteria,
      user: testUser,
    });

    return testScheduleHeader;
  };

  var containsClientHeader = function (scheduleHeader) {

    return scheduleHeader.$el.has("th:contains('Client')").length === 1;
  };

  var assertClientHeaderDisplayed = function (role) {

    var testScheduleHeader = createScheduleHeaderFor(role);

    testScheduleHeader.render();

    assert(containsClientHeader(testScheduleHeader));
  };

  it('renders client header if Report Owner', function () {

    assertClientHeaderDisplayed('REPORT_OWNER');
  });

  it('renders client header if Service Delivery', function () {

    assertClientHeaderDisplayed('SERV_DELIVER');
  });


  it('renders client header if Admin', function () {

    assertClientHeaderDisplayed('ADMIN');
  });

});
