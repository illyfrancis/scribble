/*global sinon*/
var ScheduleDetail = require('../../../../../src/main/js/views/schedules/scheduleDetail');
var Schedule = require('../../../../../src/main/js/models/schedule');
var User = require('../../../../../src/main/js/models/user');

var assert = require('assert');

describe('ScheduleDetail View', function () {

  var testSchedule, testUser, testScheduleDetail;

  var contains = function (selector) {
    return testScheduleDetail.$el.find(selector).length === 1;
  };

  describe('renders if Report Owner', function () {

    describe('with non-null editUrlTemplate on model', function () {

      var externalResources;

      beforeEach(function () {

        testSchedule = new Schedule({
          'reportOwnerId': 'A012345',
          'reportName': 'test report name',
          'editUrlTemplate': '{portalBaseUrl}/app?url={appBaseUrl}/path?id={favoriteName}'
        });
        sinon.spy(testSchedule, 'getEditUrl');

        externalResources = {
          'portalUrl': 'https://portal.bbh.com',
          'schedulingAppUrl': 'https://app.bbh.com',
          'reportingAppUrl': 'https://reporting.bbh.com'
        };

        testUser = new User({
          'id': 'A012345',
          'roles': ['REPORT_OWNER']
        });
        testUser.setExternalResources(externalResources);

        testScheduleDetail = new ScheduleDetail({
          user: testUser,
          model: testSchedule
        });

        testScheduleDetail.render();
      });

      afterEach(function () {
        testSchedule.getEditUrl.restore();
      });

      it('"edit" button as enabled', function () {
        assert(contains('.edit-schedule'));
      });

      it('"run now" button as enabled', function () {
        assert(contains('.run-schedule'));
      });

      it('provides model with external resource information when retrieving edit URL', function () {

        testScheduleDetail.getEditUrl();

        assert(testSchedule.getEditUrl.calledOnce);
        sinon.assert.calledWith(testSchedule.getEditUrl, sinon.match(externalResources));
      });
    });

    describe('with null editUrlTemplate on model', function () {

      beforeEach(function () {

        testSchedule = new Schedule({
          'reportOwnerId': 'A012345',
          'editUrlTemplate': null
        });
        testUser = new User({
          'id': 'A012345',
          'roles': ['REPORT_OWNER']
        });

        testScheduleDetail = new ScheduleDetail({
          user: testUser,
          model: testSchedule
        });

        testScheduleDetail.render();
      });

      it('"edit" button as disabled', function () {
        assert(contains('.edit-schedule') === false);
      });

      it('"run now" button as enabled', function () {
        assert(contains('.run-schedule'));
      });
    });
  });

  describe('renders if Recipient', function () {

    beforeEach(function () {

      testSchedule = new Schedule({
        'reportOwnerId': 'A012345'
      });
      testUser = new User({
        'id': 'B012345',
        'roles': ['REPORT_OWNER']
      });

      testScheduleDetail = new ScheduleDetail({
        user: testUser,
        model: testSchedule
      });

      testScheduleDetail.render();
    });

    it('"edit" button as disabled', function () {
      assert(contains('.edit-schedule') === false);
    });

    it('"run now" button as disabled', function () {
      assert(contains('.run-schedule') === false);
    });
  });

  describe('renders if Service Delivery', function () {

    beforeEach(function () {

      testSchedule = new Schedule({
        'reportOwnerId': 'A012345'
      });
      testUser = new User({
        'id': 'B012345',
        'roles': ['REPORT_OWNER', 'SERV_DELIVER']
      });

      testScheduleDetail = new ScheduleDetail({
        user: testUser,
        model: testSchedule
      });

      testScheduleDetail.render();
    });

    it('"edit" button as disabled', function () {
      assert(contains('.edit-schedule') === false);
    });

    it('"run now" button as disabled', function () {
      assert(contains('.run-schedule') === false);
    });
  });

  describe('renders if Admin', function () {

    beforeEach(function () {

      testSchedule = new Schedule({
        'reportOwnerId': 'A012345'
      });
      testUser = new User({
        'id': 'B012345',
        'roles': ['REPORT_OWNER', 'ADMIN']
      });

      testScheduleDetail = new ScheduleDetail({
        user: testUser,
        model: testSchedule
      });

      testScheduleDetail.render();
    });

    it('"edit" button as disabled', function () {
      assert(contains('.edit-schedule') === false);
    });

    it('"run now" button as disabled', function () {
      assert(contains('.run-schedule') === false);
    });
  });
});
