/*global sinon*/
/*global window: false */
var Errors = require('../../../../../src/main/js/views/dashboard/errors');

var assert = require('assert');

describe('Errors', function () {

  describe('handle ajax errors when', function () {

    var errors, errorsViewSpy, windowSpy;

    beforeEach(function () {

      errorsViewSpy = sinon.spy(Errors.prototype, 'displayNotification');
      // stubbing window.alert does not work in IE8
      window.alert = sinon.stub();
      windowSpy = window.alert;

      errors = new Errors();
    });

    afterEach(function () {

      Errors.prototype.displayNotification.restore();
      // in IE8 restoring the spy (windowSpy.restore()) causes error
    });

    it('response status is equal to 0', function () {

      errors.$el.trigger('ajaxError', {
        status: 0
      });

      assert.equal('Connection to the server is dead / terminated, please try again', errorsViewSpy.firstCall.args[0]);
    });

    it('response status is equal to 401', function () {

      errors.$el.trigger('ajaxError', {
        status: 401
      });

      assert.equal('User not logged in / Session expired, please log in', errorsViewSpy.firstCall.args[0]);
    });

    it('response status is equal to 403', function () {

      errors.$el.trigger('ajaxError', {
        status: 403
      });

      assert.equal('User not authorized', windowSpy.firstCall.args[0]);
      sinon.assert.notCalled(errorsViewSpy);
    });

    it('response status is equal to 500', function () {

      errors.$el.trigger('ajaxError', {
        status: 500
      });

      assert.equal('Error occurred, please try again later', errorsViewSpy.firstCall.args[0]);
    });

    it('another response status', function () {

      errors.$el.trigger('ajaxError', {
        status: 400
      });

      assert.equal('Error occurred, please contact support team', errorsViewSpy.firstCall.args[0]);
    });
  });

});
