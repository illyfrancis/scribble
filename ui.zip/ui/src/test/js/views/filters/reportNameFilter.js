/*global sinon*/
var ReportName = require('../../../../../src/main/js/models/criteria/reportName');
var ReportNameFilter = require('../../../../../src/main/js/views/filters/reportNameFilter');

var assert = require('assert');

describe('ReportNameFilter', function () {

  var filter, reportName;

  beforeEach(function () {
    // spy on filter - need to restore after each test
    sinon.spy(ReportNameFilter.prototype, 'render');
    sinon.spy(ReportNameFilter.prototype, 'showError');
    sinon.spy(ReportNameFilter.prototype, 'clearError');

    reportName = new ReportName({
      'id': 'reportName',
      'title': 'Report Name'
    });

    filter = new ReportNameFilter({
      model: reportName
    });
  });

  afterEach(function () {
    ReportNameFilter.prototype.render.restore();
    ReportNameFilter.prototype.showError.restore();
    ReportNameFilter.prototype.clearError.restore();
  });

  it('renders when filter changes', function () {
    reportName.trigger('change:filter');

    assert(filter.render.calledOnce);
  });

  it('shows error when filter is invalid', function () {
    filter.render();
    reportName.trigger('invalid', reportName, 'bad report name');

    assert(filter.showError.calledOnce);
  });

  it('copies filter value when input lose focus', function () {
    sinon.spy(reportName, 'setFilter');

    filter.render();
    filter.$('input').blur();

    assert(reportName.setFilter.calledOnce);
  });

  it('calls clearError when keydown', function () {
    filter.render();
    filter.$('input').keydown();

    assert(filter.clearError.calledOnce);
  });

  it('shows error message if no error was shown already', function () {
    filter.render();
    filter.showError(reportName, 'wrong report name');

    assert(filter.$el.hasClass('has-error'));
  });

  it('clears error message if error was shown', function () {
    filter.render();
    filter.$el.addClass('has-error');
    filter.clearError();

    assert(!filter.$el.hasClass('has-error'));
  });

});
