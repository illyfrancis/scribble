/*global sinon*/
var DateRange = require('../../../../../src/main/js/models/criteria/dateRange');
var DateRangeFilter = require('../../../../../src/main/js/views/filters/dateRangeFilter');

var assert = require('assert');

describe('DateRangeFilter', function () {

  var TEST_DATE = new Date(1);
  var filter, dateRange;

  beforeEach(function () {
    sinon.spy(DateRangeFilter.prototype, 'showError');
    sinon.spy(DateRangeFilter.prototype, 'clearError');
    sinon.stub(DateRangeFilter.prototype, 'getDateFromField').returns(TEST_DATE);
    sinon.spy(DateRange.prototype, 'setToDate');
    sinon.spy(DateRange.prototype, 'setFromDate');

    dateRange = new DateRange({
      'id': 'dateRangeField',
      'title': 'Date Range'
    });

    filter = new DateRangeFilter({
      model: dateRange
    });
  });

  afterEach(function () {
    DateRangeFilter.prototype.showError.restore();
    DateRangeFilter.prototype.clearError.restore();
    DateRangeFilter.prototype.getDateFromField.restore();
    DateRange.prototype.setToDate.restore();
    DateRange.prototype.setFromDate.restore();
  });

  it('shows error when filter is invalid', function () {
    dateRange.trigger('invalid', dateRange, 'both dates are required');
    assert(filter.showError.calledOnce);
  });

  it('clears error when *to* date is updated', function () {
    filter.changeToDate();
    assert(filter.clearError.calledOnce);
  });

  it('clears error when *from* date is updated', function () {
    filter.changeFromDate();
    assert(filter.clearError.calledOnce);
  });

  it('updates model when *to* date is updated', function () {
    filter.changeToDate();
    assert(dateRange.setToDate.calledWith(TEST_DATE));
  });

  it('updates model when *from* date is updated', function () {
    filter.changeFromDate();
    assert(dateRange.setFromDate.calledWith(TEST_DATE));
  });
});
