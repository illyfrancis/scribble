var UpcomingRuntime = require('../../../../src/main/js/models/upcomingRuntime');

var assert = require('assert');
var sinon = require('sinon');

describe('Upcoming Runtime', function () {

  // enable cache
  require('../../../../src/main/js/app').ajaxSetup({
    cache: true
  });

  var server;
  var upcomingRuntime;

  beforeEach(function () {
    server = sinon.fakeServer.create();

    upcomingRuntime = new UpcomingRuntime({
      scheduleId: 123
    });

  });

  afterEach(function () {
    server.restore();
  });

  it('builds upcoming runtime URL', function () {
    var upcomingRuntimeUrl = upcomingRuntime.urlRoot();
    assert.equal(upcomingRuntimeUrl, './api/schedules/123/upcomingruntimes');
  });

  it('can parse runtimes array with one element', function () {
    server.respondWith('GET', './api/schedules/123/upcomingruntimes', [200, {
        'Content-Type': 'application/json'
      },
      '{"runtimes": ["2015-02-05T02:00:00Z"]}'
    ]);

    upcomingRuntime.fetch();
    server.respond();

    assert.equal(upcomingRuntime.get('runtime'), '2015-02-05T02:00:00Z');
  });

  it('can parse empty runtimes array', function () {
    server.respondWith('GET', './api/schedules/123/upcomingruntimes', [200, {
        'Content-Type': 'application/json'
      },
      '{"runtimes": []}'
    ]);

    upcomingRuntime.fetch();
    server.respond();

    assert.equal(upcomingRuntime.get('runtime'), '');
  });

  it('performs fetch only once', function () {

    sinon.spy(upcomingRuntime, 'fetch');

    server.respondWith('GET', './api/schedules/123/upcomingruntimes', [200, {
        'Content-Type': 'application/json'
      },
      '{"runtimes": []}'
    ]);

    upcomingRuntime.next();
    upcomingRuntime.next();
    server.respond();

    assert(upcomingRuntime.fetch.calledOnce);
  });

});
