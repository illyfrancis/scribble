/*global sinon*/
var Schedule = require('../../../../src/main/js/models/schedule');
var ScheduleFrequency = require('../../../../src/main/js/models/scheduleFrequency');

var assert = require('assert');

describe('Schedule', function () {

  var scheduleFrequency = new ScheduleFrequency();
  var schedule = new Schedule({
    frequencyDetail : scheduleFrequency
  });

  var externalResources = {
    portalUrl: "https://portal.bbh.com",
    schedulingAppUrl: "https://app.bbh.com",
    reportingAppUrl: "https://reporting.bbh.com"
  };

  describe('formats frequency detail', function () {

    beforeEach(function () {
      sinon.spy(scheduleFrequency, 'formatDetail');
    });

    afterEach(function () {
       scheduleFrequency.formatDetail.restore();
    });

    it('using schedule frequency model', function () {

      schedule.formatFrequencyDetail();

      assert(scheduleFrequency.formatDetail.calledOnce);
    });
  });

  describe('formats week days', function () {

    beforeEach(function () {
      sinon.spy(scheduleFrequency, 'formatWeekDays');
    });

    afterEach(function () {
      scheduleFrequency.formatWeekDays.restore();
    });

    it('using schedule frequency model', function () {

      schedule.formatWeekDays();

      assert(scheduleFrequency.formatWeekDays.calledOnce);
    });
  });

  describe('generates edit URL for a TR schedule', function () {

    it('with report name that does not require encoding', function () {

      var trSchedule = new Schedule({
        reportName: 'reportName',
        editUrlTemplate: '{portalBaseUrl}/app?url={appBaseUrl}/path?id={favoriteName}'
      });

      var url = trSchedule.getEditUrl(externalResources);
      assert.equal(url, 'https://portal.bbh.com/app?url=https://app.bbh.com/path?id=reportName');
    });

    it('with report name that requires encoding', function () {

      var trSchedule = new Schedule({
        reportName: 'test report name',
        editUrlTemplate: '{portalBaseUrl}/app?url={appBaseUrl}/path?id={favoriteName}'
      });

      var url = trSchedule.getEditUrl(externalResources);
      assert.equal(url, 'https://portal.bbh.com/app?url=https://app.bbh.com/path?id=test%20report%20name');
    });
  });

  describe('generates edit URL for a Cognos schedule', function () {

    it('with report name that does not require encoding', function () {

      var cognosSchedule = new Schedule({
        reportName: 'reportName',
        externalId: 'externalId',
        editUrlTemplate: '{reportingBaseUrl}/CognosProxy/scheduler?storeID={externalId}%26defaultName={favoriteName}'
      });

      var url = cognosSchedule.getEditUrl(externalResources);
      assert.equal(url, 'https://reporting.bbh.com/CognosProxy/scheduler?storeID=externalId%26defaultName=reportName');
    });

    it('with report name that requires encoding', function () {

      var cognosSchedule = new Schedule({
        reportName: 'test report name',
        externalId: 'externalId',
        editUrlTemplate: '{reportingBaseUrl}/CognosProxy/scheduler?storeID={externalId}%26defaultName={favoriteName}'
      });

      var url = cognosSchedule.getEditUrl(externalResources);
      assert.equal(url, 'https://reporting.bbh.com/CognosProxy/scheduler?storeID=externalId%26defaultName=test%20report%20name');
    });
  });

  it('generates a null edit URL when the edit URL template is null', function () {
    var scheduleWithNullTemplate = new Schedule({
      reportName: 'test report name',
      externalId: 'externalId',
      editUrlTemplate: null
    });

    var url = scheduleWithNullTemplate.getEditUrl(externalResources);
    assert.equal(url, null);
  });
});
