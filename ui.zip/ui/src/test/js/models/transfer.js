/*global sinon*/
var assert = require('assert');
var Transfer = require('../../../../src/main/js/models/transfer');

describe('Transfer', function () {

  var TRANSFER_ID = 1234;
  var USER_ID = 'U0001';

  var defaults = {
    id: TRANSFER_ID,
    scheduleId: 4567,
    reportName: 'report name',
    reportOwner: 'NJ1234',
    requestedOn: '',
    requestExpiry: '',
    requestedBy: '',
    transferTo: '',
    status: 'PENDING'
  };

  describe('accepting transfer', function () {

    // enable cache
    // require('../../../../src/main/js/app').ajaxSetup({
    //   cache: true
    // });

    var ACCEPT_API = './api/transfers/{id}/accept/by/{userId}';
    var expectedUrl = ACCEPT_API.replace('{id}', TRANSFER_ID).replace('{userId}', USER_ID);

    var server;
    var transfer;

    beforeEach(function () {
      server = sinon.fakeServer.create();
      transfer = new Transfer(defaults);
      sinon.spy(transfer, 'onAcceptComplete');
      sinon.spy(transfer, 'onTransferFailure');
    });

    afterEach(function () {
      server.restore();
      transfer.onAcceptComplete.restore();
      transfer.onTransferFailure.restore();
    });

    it('invokes correct API', function () {
      transfer.acceptTransfer(USER_ID);

      assert.equal(server.requests[0].url, expectedUrl);
      assert.equal(server.requests[0].method, 'POST');
    });

    it('completes transfer when there is no error', function () {
      server.respondWith('POST', expectedUrl, [204, {
          'Content-Type': 'application/json'
        },
        '{"httpStatus": 400}'
      ]);

      transfer.acceptTransfer(USER_ID);
      server.respond();

      assert(transfer.onAcceptComplete.calledOnce);
      assert.equal(transfer.onTransferFailure.callCount, 0);
    });
/*
    it('fails when there is validation error', function () {
      server.respondWith('POST', expectedUrl, [400, {
          'Content-Type': 'application/json'
        },
        // '{
        //   "httpStatus": 400,
        //   "multipartExceptionParts": [{
        //     "code": 1234,
        //     "category": "",
        //     "message": "a descriptive message",
        //     "detail": "",
        //     "additionalInfo": ""
        //   }]
        // }'
        '{"httpStatus": 400}'
      ]);

      transfer.acceptTransfer(USER_ID);
      server.respond();

      assert(transfer.onTransferFailure.calledOnce);
      assert.equal(transfer.onAcceptComplete.callCount, 0);
    });
*/

  });

});
