/*global sinon*/
var assert = require('assert');
var Criteria = require('../../../../src/main/js/collections/criteria');
var ReportName = require('../../../../src/main/js/models/criteria/reportName');

describe('Criteria', function () {

  var API_URI = './api/settings/filters';

  describe('interacting with API', function () {
    var xhr, requests;

    beforeEach(function () {
      xhr = sinon.useFakeXMLHttpRequest();
      requests = [];
      xhr.onCreate = function (req) {
        requests.push(req);
      };
    });

    afterEach(function () {
      xhr.restore();
    });

    it('consumes from Settings API', function () {

      var criteria = new Criteria();
      criteria.load();

      assert.equal(1, requests.length);
      assert(requests[0].url.indexOf(API_URI) > -1);
    });

    it('saves settings using Settings API', function () {

      var reportName = new ReportName();
      var criteria = new Criteria(reportName);
      criteria.save();

      assert.equal(API_URI, requests[0].url);
      assert.equal('POST', requests[0].method);
      assert.equal(JSON.stringify(criteria), requests[0].requestBody);
    });

  });

  describe('with fake server', function () {

    // enable cache
    require('../../../../src/main/js/app').ajaxSetup({cache: true});

    var server;

    var userSettings = { 
      'filters': [{
          'id': 'reportName',
          'title': 'Report name',
          'displayOrder': 0,
          'filter': 'Failed Transaction',
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'reportCategory',
          'filterWith': 'reportCategoryId',
          'sortWith': 'reportCategory',
          'title': 'Report category',
          'displayOrder': 1,
          'filter': 'Transaction Reporting',
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'reportType',
          'filterWith': 'reportTypeCode',
          'sortWith': 'reportType',
          'title': 'Report type',
          'displayOrder': 2,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'reportOwner',
          'filterWith': 'reportOwnerId',
          'sortWith': 'reportOwnerName',
          'title': 'Report owner',
          'displayOrder': 3,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'createdBy',
          'filterWith': 'createdById',
          'sortWith': 'createdByName',
          'title': 'Created by',
          'displayOrder': 4,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'modifiedBy',
          'filterWith': 'modifiedById',
          'sortWith': 'modifiedByName',
          'title': 'Modified by',
          'displayOrder': 5,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'frequency',
          'title': 'Frequency',
          'displayOrder': 6,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'trigger',
          'title': 'Trigger',
          'displayOrder': 7,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'distributionList',
          'title': 'Distribution list',
          'displayOrder': 8,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'lastExecution',
          'title': 'Last execution',
          'displayOrder': 9,
          'filter': {
              'from': null,
              'to': null
          },
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'distributionFormat',
          'title': 'Delivery',
          'displayOrder': 10,
          'filter': null,
          'isSortable': false,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'clients',
          'filterWith': 'clientId',
          'sortWith': 'clientId',
          'title': 'Client',
          'displayOrder': 11,
          'groupOrder': 0,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0
      }, {
          'id': 'reportExpiry',
          'title': 'Report expiry',
          'displayOrder': 12,
          'filter': {
              'from': null,
              'to': null
          },
          'isSortable': true,
          'sortOrder': 1,
          'groupOrder': 0
      }]
    };

    var tmpUserSettings = { 
      'filters': [{
          'id': 'reportName',
          'title': 'Report name',
          'displayOrder': 0,
          'filter': 'Tmp Failed Transaction',
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'reportCategory',
          'filterWith': 'reportCategoryId',
          'sortWith': 'reportCategory',
          'title': 'Report category',
          'displayOrder': 1,
          'filter': 'Tmp Transaction Reporting',
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'reportType',
          'filterWith': 'reportTypeCode',
          'sortWith': 'reportType',
          'title': 'Report type',
          'displayOrder': 2,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'reportOwner',
          'filterWith': 'reportOwnerId',
          'sortWith': 'reportOwnerName',
          'title': 'Report owner',
          'displayOrder': 3,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'createdBy',
          'filterWith': 'createdById',
          'sortWith': 'createdByName',
          'title': 'Created by',
          'displayOrder': 4,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'modifiedBy',
          'filterWith': 'modifiedById',
          'sortWith': 'modifiedByName',
          'title': 'Modified by',
          'displayOrder': 5,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'frequency',
          'title': 'Frequency',
          'displayOrder': 6,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'distributionList',
          'title': 'Distribution list',
          'displayOrder': 8,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'lastExecution',
          'title': 'Last execution',
          'displayOrder': 9,
          'filter': {
              'from': null,
              'to': null
          },
          'isSortable': true,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'distributionFormat',
          'title': 'Delivery',
          'displayOrder': 10,
          'filter': null,
          'isSortable': false,
          'sortOrder': 0,
          'groupOrder': 0
      }, {
          'id': 'clients',
          'filterWith': 'clientId',
          'sortWith': 'clientId',
          'title': 'Client',
          'displayOrder': 11,
          'groupOrder': 0,
          'filter': null,
          'isSortable': true,
          'sortOrder': 0
      }, {
          'id': 'reportExpiry',
          'title': 'Report expiry',
          'displayOrder': 12,
          'filter': {
              'from': null,
              'to': null
          },
          'isSortable': true,
          'sortOrder': 1,
          'groupOrder': 0
      }]
    };

    beforeEach(function () {
      server = sinon.fakeServer.create();
    });

    afterEach(function () {
      server.restore();
    });

    it('loads default criteria', function () {
      server.respondWith('GET', './api/settings', [200, {
          'Content-Type': 'application/json'
        },
        '[]'
      ]);

      var criteria = new Criteria();
      criteria.load();

      server.respond();

      assert.equal(12, criteria.size());
      assert.equal(null, criteria.get('reportName').get('filter'));
      assert.equal(null, criteria.get('reportCategory').get('filter'));

    });

    it('loads user criteria', function () {
      server.respondWith('GET', './api/settings/filters', [200, {
          'Content-Type': 'application/json'
        },
        JSON.stringify(userSettings)
      ]);

      var criteria = new Criteria();
      criteria.load();

      server.respond();

      assert.equal(12, criteria.size());
      assert.equal('Failed Transaction', criteria.get('reportName').get('filter'));
      assert.equal('Transaction Reporting', criteria.get('reportCategory').get('filter'));
    });

    it('overrides temporary criteria with user settings', function () {
      server.respondWith('GET', './api/settings/filters', [200, {
          'Content-Type': 'application/json'
        },
        JSON.stringify(userSettings)
      ]);

      var criteria = new Criteria(tmpUserSettings.filters);
      assert.equal(12, criteria.size());
      assert.equal('Tmp Failed Transaction', criteria.get('reportName').get('filter'));
      assert.equal('Tmp Transaction Reporting', criteria.get('reportCategory').get('filter'));

      criteria.load();

      server.respond();

      assert.equal(12, criteria.size());
      assert.equal('Failed Transaction', criteria.get('reportName').get('filter'));
      assert.equal('Transaction Reporting', criteria.get('reportCategory').get('filter'));
    });    
  });

});
