var assert = require('assert');
var Transfers = require('../../../../src/main/js/collections/transfers');

describe('Transfers', function () {

  describe('initialize', function () {
    it('successfully when both user id and direction is specified', function () {
      var from = function () {
        new Transfers([], {userId: '123', direction: 'outgoing'});
      };
      var to = function () {
        new Transfers([], {userId: '123', direction: 'incoming'});
      };

      assert.doesNotThrow(from, Error);
      assert.doesNotThrow(to, Error);
    });
  });

  describe('url', function () {
    it('is outgoing transfers', function () {
      var USER_ID = '123';
      var outgoing = new Transfers([], {userId: USER_ID, direction: 'outgoing'});
      assert.equal(outgoing.url(), './api/transfers/from/' + USER_ID);
    });

    it('is incoming transfers', function () {
      var USER_ID = '123';
      var incoming = new Transfers([], {userId: USER_ID, direction: 'incoming'});
      assert.equal(incoming.url(), './api/transfers/to/' + USER_ID);
    });
  });

});
