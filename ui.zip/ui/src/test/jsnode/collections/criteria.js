var Backbone = require('backbone');
var Criterion = require('../../../../src/main/js/models/criteria/criterion');
var Criteria = require('../../../../src/main/js/collections/criteria');
var Settings = require('../../../../src/main/js/collections/settings');

var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');

describe('Criteria', function () {

  var criteria = {};

  beforeEach(function () {
    criteria = new Criteria();
  });

  it('has a url string', function () {
    expect(criteria.url).to.be.a('string').and.equal('./api/settings/filters');
  });

  it('has default set of criterion', function () {
    expect(criteria.size()).to.equal(Settings.defaults().length);
  });

  it('sorts the elements by displayOrder', function () {
    var elements = [{
      'id': 'Four',
      'displayOrder': 4
    }, {
      'id': 'One',
      'displayOrder': 1
    }, {
      'id': 'Three',
      'displayOrder': 3
    }, {
      'id': 'Two',
      'displayOrder': 2
    }];
    criteria.reset(elements);

    expect(criteria.at(0).get('id')).to.equal('One');
    expect(criteria.at(1).get('id')).to.equal('Two');
    expect(criteria.at(2).get('id')).to.equal('Three');
    expect(criteria.at(3).get('id')).to.equal('Four');
  });

  it('returns an empty query when there\'s no criterion', function () {
    expect(criteria.toQuery()).to.eql({
      query: "{}",
      sorts: [{
        field: 'reportOwnerName',
        order: 1
      }]
    });
  });

  it('returns a query from a criteria when one criterion is set', function () {
    var query1 = {
        'key': 'value'
      },
      criterion = new Criterion();

    sinon.stub(criterion, 'toQuery').returns(query1);
    sinon.stub(criterion, 'isFilterSet').returns(true);

    criteria.add(criterion);

    expect(criteria.toQuery()).to.eql({
      query: JSON.stringify(query1),
      sorts: [{
        field: 'reportOwnerName',
        order: 1
      }]
    });
  });

  it('returns a combined query when multiple criteria is set', function () {
    var query1 = {
        'key1': 'val1'
      },
      query2 = {
        'key2': 'val2'
      },
      query3 = {
        'key3': 'val3'
      },
      criterion1 = new Criterion(),
      criterion2 = new Criterion(),
      criterion3 = new Criterion();

    sinon.stub(criterion1, 'isFilterSet').returns(true);
    sinon.stub(criterion1, 'toQuery').returns(query1);

    sinon.stub(criterion2, 'isFilterSet').returns(true);
    sinon.stub(criterion2, 'toQuery').returns(query2);

    sinon.stub(criterion3, 'isFilterSet').returns(true);
    sinon.stub(criterion3, 'toQuery').returns(query3);

    criteria.add(criterion1);
    criteria.add(criterion2);
    criteria.add(criterion3);

    expect(criteria.toQuery()).to.eql({
      query: JSON.stringify({
        '$and': [query1, query2, query3]
      }),
      sorts: [{
        field: 'reportOwnerName',
        order: 1
      }]
    });
  });

  it('returns a combined query only for criteria with filter value set', function () {
    var query1 = {
        'key1': 'val1'
      },
      query2 = {
        'key2': 'val2'
      },
      query3 = {
        'key3': 'val3'
      },
      criterion1 = new Criterion(),
      criterion2 = new Criterion(),
      criterion3 = new Criterion();

    sinon.stub(criterion1, 'isFilterSet').returns(true);
    sinon.stub(criterion1, 'toQuery').returns(query1);

    sinon.stub(criterion2, 'isFilterSet').returns(false);
    sinon.stub(criterion2, 'toQuery').returns(query2);

    sinon.stub(criterion3, 'isFilterSet').returns(true);
    sinon.stub(criterion3, 'toQuery').returns(query3);

    criteria.add(criterion1);
    criteria.add(criterion2);
    criteria.add(criterion3);

    expect(criteria.toQuery()).to.eql({
      query: JSON.stringify({
        '$and': [query1, query3]
      }),
      sorts: [{
        field: 'reportOwnerName',
        order: 1
      }]
    });
  });

  it('returns sort field from a criteria when one criterion is set', function () {
    var criterion = new Criterion({
      id: 'criterion1',
      sortOrder: -1
    });

    criteria.add(criterion);

    expect(criteria.toQuery()).to.eql({
      query: "{}",
      sorts: [{
        field: 'reportOwnerName',
        order: 1
      }, {
        field: 'criterion1',
        order: -1
      }]
    });
  });

  it('returns sort fields from a criteria when two criterion are set', function () {
    var criterion1 = new Criterion({
      id: 'criterion1'
    });

    var criterion2 = new Criterion({
      id: 'criterion2',
      sortOrder: -1
    });

    criteria.add(criterion1);
    criteria.add(criterion2);

    expect(criteria.toQuery()).to.eql({
      query: "{}",
      sorts: [{
        field: 'reportOwnerName',
        order: 1
      }, {
        field: 'criterion2',
        order: -1
      }]
    });
  });

  it('does not override default titles when criteria is loaded', function () {
    var sync = sinon.stub(Backbone, 'sync', function (method, model, options) {
      // as per Backbone spec for sync (http://backbonejs.org/#Sync)
      // not needed for this test per se.
      model.trigger('request', model, xhr, options);

      var response = {
        "filters": [{
          "id": "reportName",
          "title": "DIFFERENT TITLE",
          "displayOrder": 0,
          "filter": "",
          "isSortable": true,
          "sortOrder": 0
        }]
      };

      options.success(response);

      var xhr = {};
      return xhr;
    });

    var reportName = criteria.get('reportName');
    var defaultTitle = reportName.get('title');

    criteria.load();

    var postLoadTitle = criteria.get('reportName').get('title');
    expect(postLoadTitle).to.equal(defaultTitle);

    sync.restore();
  });

  describe('Default elements in criteria', function () {

    describe('ReportName', function () {
      var reportName;
      beforeEach(function () {
        reportName = criteria.get('reportName');
      });

      it('exists in default Criteria', function () {
        expect(reportName).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(reportName.filterWith()).is.eql('reportName');
      });
    });

    describe('CreatedBy', function () {
      var createdBy;
      beforeEach(function () {
        createdBy = criteria.get('createdBy');
      });

      it('exists in default Criteria', function () {
        expect(createdBy).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(createdBy.filterWith()).is.eql('createdById');
      });
    });

    describe('Client', function () {
      var client;
      beforeEach(function () {
        client = criteria.get('clients');
      });

      it('exists in default Criteria', function () {
        expect(client).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(client.filterWith()).is.eql('clientId');
      });
    });

    describe('DistributionFormat', function () {
      var distributionFormat;
      beforeEach(function () {
        distributionFormat = criteria.get('distributionFormat');
      });

      it('exists in default Criteria', function () {
        expect(distributionFormat).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(distributionFormat.filterWith()).is.eql('distributionFormat');
      });
    });

    describe('DistributionList', function () {
      var distributionList;
      beforeEach(function () {
        distributionList = criteria.get('distributionList');
      });

      it('exists in default Criteria', function () {
        expect(distributionList).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(distributionList.filterWith()).is.eql('distributionList');
      });
    });

    describe('Frequency', function () {
      var frequency;
      beforeEach(function () {
        frequency = criteria.get('frequency');
      });

      it('exists in default Criteria', function () {
        expect(frequency).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(frequency.filterWith()).is.eql('frequency');
      });
    });

    describe('LastExecution', function () {
      var lastExecution;
      beforeEach(function () {
        lastExecution = criteria.get('lastExecution');
      });

      it('exists in default Criteria', function () {
        expect(lastExecution).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(lastExecution.filterWith()).is.eql('lastExecution');
      });
    });

    describe('ModifiedBy', function () {
      var modifiedBy;
      beforeEach(function () {
        modifiedBy = criteria.get('modifiedBy');
      });

      it('exists in default Criteria', function () {
        expect(modifiedBy).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(modifiedBy.filterWith()).is.eql('modifiedById');
      });
    });

    describe('ReportCategory', function () {
      var reportCategory;
      beforeEach(function () {
        reportCategory = criteria.get('reportCategory');
      });

      it('exists in default Criteria', function () {
        expect(reportCategory).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(reportCategory.filterWith()).is.eql('reportCategoryId');
      });
    });

    describe('ReportExpiry', function () {
      var reportExpiry;
      beforeEach(function () {
        reportExpiry = criteria.get('reportExpiry');
      });

      it('exists in default Criteria', function () {
        expect(reportExpiry).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(reportExpiry.filterWith()).is.eql('reportExpiry');
      });
    });

    describe('ReportOwner', function () {
      var reportOwner;
      beforeEach(function () {
        reportOwner = criteria.get('reportOwner');
      });

      it('exists in default Criteria', function () {
        expect(reportOwner).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(reportOwner.filterWith()).is.eql('reportOwnerId');
      });
    });

    describe('ReportType', function () {
      var reportType;
      beforeEach(function () {
        reportType = criteria.get('reportType');
      });

      it('exists in default Criteria', function () {
        expect(reportType).is.not.an('undefined');
      });

      it('filters with', function () {
        expect(reportType.filterWith()).is.eql('reportTypeCode');
      });
    });
  });

});
