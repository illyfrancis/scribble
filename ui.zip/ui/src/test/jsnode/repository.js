var assert = require('assert');

describe('Repository', function () {

  it('has user with external resources url initialized', function () {
    global.dashboard = {
      externalResources: {
        'portalUrl': 'PORTAL_URL',
        'schedulingAppUrl': 'SCHEDULE_APP_URL',
        'reportingAppUrl': 'REPORT_APP_URL'
      }
    };

    var repository = require('../../../src/main/js/repository');

    var user = repository.user();
    var external = user.get('externalResources');

    assert.equal(external.portalUrl, 'PORTAL_URL');
    assert.equal(external.schedulingAppUrl, 'SCHEDULE_APP_URL');
    assert.equal(external.reportingAppUrl, 'REPORT_APP_URL');
  });

});
