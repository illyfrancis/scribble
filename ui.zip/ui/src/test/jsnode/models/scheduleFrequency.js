var ScheduleFrequency = require('../../../../src/main/js/models/scheduleFrequency');

var assert = require('assert');

describe('Schedule Frequency', function () {

  var scheduleFrequency;

  beforeEach(function () {
    scheduleFrequency = new ScheduleFrequency();
  });

  describe('formats frequency tooltip', function () {

    it('if daily schedule', function () {

      scheduleFrequency.set('scheduleType', 'DAILY');

      assert.equal(scheduleFrequency.shouldFormatDetail(), true);
    });

    it('if weekly schedule', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');

      assert.equal(scheduleFrequency.shouldFormatDetail(), true);
    });

    it('if monthly schedule', function () {

      scheduleFrequency.set('scheduleType', 'MONTHLY');

      assert.equal(scheduleFrequency.shouldFormatDetail(), true);
    });

    it('not if trigger schedule', function () {

      scheduleFrequency.set('scheduleType', 'TRIGGER');

      assert.equal(scheduleFrequency.shouldFormatDetail(), false);
    });

    it('as simple weekly schedule with start date', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '17:30');

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30pm');
    });

    it('as simple weekly schedule with range having minutes', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('intradayStartTime', '06:00');
      scheduleFrequency.set('intradayEndTime', '08:00');
      scheduleFrequency.set('intradayInterval', '6');
      scheduleFrequency.set('intradayPeriod', 'MINUTE');

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30am between 6:00am and 8:00am every 6 minute(s)');
    });

    it('as simple weekly schedule with range having hours', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('intradayStartTime', '16:00');
      scheduleFrequency.set('intradayEndTime', '18:00');
      scheduleFrequency.set('intradayInterval', '1');
      scheduleFrequency.set('intradayPeriod', 'HOUR');

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30am between 4:00pm and 6:00pm every 1 hour(s)');
    });

    it('as simple weekly schedule with range having days', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('intradayStartTime', '09:00');
      scheduleFrequency.set('intradayEndTime', '13:00');
      scheduleFrequency.set('intradayInterval', '2');
      scheduleFrequency.set('intradayPeriod', 'DAY');

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30am between 9:00am and 1:00pm every 2 day(s)');
    });

    it('as weekly schedule with upper cased week day as capitalized', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('weekDay', 'MONDAY');

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30am on Monday');
    });

    it('as weekly schedule with upper cased week days as capitalized', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('weekDay', 'MONDAY,TUESDAY,WEDNESDAY');

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30am on Monday, Tuesday, Wednesday');
    });

    it('as weekly schedule with upper cased and unordered week days as capitalized', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('weekDay', 'WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY,MONDAY,TUESDAY');

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30am on Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday');
    });

    it('as monthly schedule with negative absolute month day and business days', function () {

      scheduleFrequency.set('scheduleType', 'MONTHLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('absMonthDay', -2);
      scheduleFrequency.set('weekDaysOnly', true);

      assert.equal(scheduleFrequency.formatDetail(), 'Monthly starting at 5:30am on 2nd business day before month end');
    });

    it('as monthly schedule with positive absolute month day and business days', function () {

      scheduleFrequency.set('scheduleType', 'MONTHLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('absMonthDay', 5);
      scheduleFrequency.set('weekDaysOnly', true);

      assert.equal(scheduleFrequency.formatDetail(), 'Monthly starting at 5:30am on 5th business day after month end');
    });

    it('as monthly schedule with positive absolute month day and calendar days', function () {

      scheduleFrequency.set('scheduleType', 'MONTHLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('absMonthDay', 5);

      assert.equal(scheduleFrequency.formatDetail(), 'Monthly starting at 5:30am on 5th calendar day after month end');
    });

    it('as monthly schedule without absolute month day', function () {

      scheduleFrequency.set('scheduleType', 'MONTHLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('relativeWeek', 'FIRST');
      scheduleFrequency.set('relativeWeekDay', 'MONDAY');

      assert.equal(scheduleFrequency.formatDetail(), 'Monthly starting at 5:30am on first Monday');
    });


    it('as simple weekly schedule without frequency', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '05:30');

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30am');
    });

    it('as simple weekly schedule with frequency but invalid number', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('frequency', 1);

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30am');
    });

    it('as simple daily schedule with recurrence', function () {

      scheduleFrequency.set('scheduleType', 'DAILY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('frequency', 2);
      scheduleFrequency.set('dailyPeriod', 'DAY');

      assert.equal(scheduleFrequency.formatDetail(), 'Daily starting at 5:30am every 2 day(s)');
    });

    it('as simple weekly schedule with recurrence', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('frequency', 2);

      assert.equal(scheduleFrequency.formatDetail(), 'Weekly starting at 5:30am every 2 weeks');
    });

    it('as simple monthly schedule with recurrence', function () {

      scheduleFrequency.set('scheduleType', 'MONTHLY');
      scheduleFrequency.set('startTime', '05:30');
      scheduleFrequency.set('frequency', 2);

      assert.equal(scheduleFrequency.formatDetail(), 'Monthly starting at 5:30am every 2 months');
    });
  });

  it('should convert day number', function () {

    assert.equal(scheduleFrequency.convertDayNumber(1), '1st');
    assert.equal(scheduleFrequency.convertDayNumber(21), '21st');
    assert.equal(scheduleFrequency.convertDayNumber(31), '31st');
    assert.equal(scheduleFrequency.convertDayNumber(2), '2nd');
    assert.equal(scheduleFrequency.convertDayNumber(22), '22nd');
    assert.equal(scheduleFrequency.convertDayNumber(3), '3rd');
    assert.equal(scheduleFrequency.convertDayNumber(23), '23rd');
    assert.equal(scheduleFrequency.convertDayNumber(4), '4th');
    assert.equal(scheduleFrequency.convertDayNumber(14), '14th');
    assert.equal(scheduleFrequency.convertDayNumber(24), '24th');
  });

  describe('formats frequency week days', function () {

    it('as empty if not weekly', function () {

      scheduleFrequency.set('scheduleType', 'MONTHLY');

      var weekDays = scheduleFrequency.formatWeekDays();

      assert.equal(weekDays, '');
    });

    it('as weekly with single day', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('weekDay', 'MONDAY');

      var weekDays = scheduleFrequency.formatWeekDays();

      assert.equal(weekDays, 'M');
    });

    it('as weekly with Monday through to Sunday without details', function () {

      scheduleFrequency.set('scheduleType', 'WEEKLY');
      scheduleFrequency.set('weekDay', 'WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY,MONDAY,TUESDAY');

      var weekDays = scheduleFrequency.formatWeekDays();

      assert.equal(weekDays, 'M T W TH F SA S');
    });
  });
});
