var User = require('../../../../src/main/js/models/user');

var assert = require('assert');

describe('User', function() {

  describe('Default user', function() {
    var user;

    beforeEach(function() {
      user = new User();
    });

    it('does not have SERV_DELIVERY role', function() {
      assert.equal(user.isServiceDelivery, false);
    });

    it('does not have ADMIN role', function() {
      assert.equal(user.isAdmin, false);
    });

    it('has empty external resources', function() {
      assert.deepEqual(user.get('externalResources'), {});
    });

    it('does not have ADMIN role when invoking hasAdminRole', function() {
      assert.equal(user.hasAdminRole(), false);
    });

    it('is not an internal user', function() {
      assert.equal(user.isInternal(), false);
    });

    it('is not an internal user when invoking toPermission', function() {
      assert.equal(user.toPermission().internal, false);
    });
  });

  describe('Created with role [REPORT_OWNER]', function() {
    var user;

    beforeEach(function() {
      user = new User({
        roles: ['REPORT_OWNER']
      });
    });

    it('does not have SERV_DELIVERY role', function() {
      assert.equal(user.isServiceDelivery, false);
    });

    it('does not have ADMIN role', function() {
      assert.equal(user.isAdmin, false);
    });

    it('does not have ADMIN role when invoking hasAdminRole', function() {
      assert.equal(user.hasAdminRole(), false);
    });

    it('is not an internal user', function() {
      assert.equal(user.isInternal(), false);
    });

    it('is not an internal user when invoking toPermission', function() {
      assert.equal(user.toPermission().internal, false);
    });
  });

  describe('Created with roles [REPORT_OWNER, SERV_DELIVER]', function() {
    var user;

    beforeEach(function() {
      user = new User({
        roles: ['REPORT_OWNER', 'SERV_DELIVER']
      });
    });

    it('has SERV_DELIVERY role', function() {
      assert.equal(user.isServiceDelivery, true);
    });

    it('does not have ADMIN role', function() {
      assert.equal(user.isAdmin, false);
    });

    it('does not have ADMIN role when invoking hasAdminRole', function() {
      assert.equal(user.hasAdminRole(), false);
    });

    it('is an internal user', function() {
      assert.equal(user.isInternal(), true);
    });

    it('is an internal user when invoking toPermission', function() {
      assert.equal(user.toPermission().internal, true);
    });
  });

  describe('Created with roles [REPORT_OWNER, ADMIN]', function() {
    var user;

    beforeEach(function() {
      user = new User({
        roles: ['REPORT_OWNER', 'ADMIN']
      });
    });

    it('does not have SERV_DELIVERY role', function() {
      assert.equal(user.isServiceDelivery, false);
    });

    it('has ADMIN role', function() {
      assert.equal(user.isAdmin, true);
    });

    it('has ADMIN role when invoking hasAdminRole', function() {
      assert.equal(user.hasAdminRole(), true);
    });

    it('is an internal user', function() {
      assert.equal(user.isInternal(), true);
    });

    it('is an internal user when invoking toPermission', function() {
      assert.equal(user.toPermission().internal, true);
    });
  });

  describe('Created with roles [REPORT_OWNER, SERV_DELIVER, ADMIN]', function() {
    var user;

    beforeEach(function() {
      user = new User({
        roles: ['REPORT_OWNER', 'SERV_DELIVER', 'ADMIN']
      });
    });

    it('has SERV_DELIVERY role', function() {
      assert.equal(user.isServiceDelivery, true);
    });

    it('has ADMIN role', function() {
      assert.equal(user.isAdmin, true);
    });

    it('has ADMIN role when invoking hasAdminRole', function() {
      assert.equal(user.hasAdminRole(), true);
    });

    it('is an internal user', function() {
      assert.equal(user.isInternal(), true);
    });

    it('is an internal user when invoking toPermission', function() {
      assert.equal(user.toPermission().internal, true);
    });
  });

  describe('External resources for user', function() {
    it('is created with external resources', function() {
      var systemUrl = 'A_URL';
      var user = new User();
      user.setExternalResources({
        systemName: systemUrl
      });
      var resources = user.get('externalResources');
      assert.equal(resources.systemName, systemUrl);
    });

    it('is not created with external resources', function() {
      var user = new User();
      user.setExternalResources();
      var resources = user.get('externalResources');
      assert.deepEqual(resources, {});
    });
  });

  describe('Serialization', function() {

    var user;

    it('has only id and name with default', function() {
      user = new User();

      var expected = {
        id: '',
        name: ''
      };

      assert.deepEqual(user.toJSON(), expected);
    });

    it('has only id and name when bootstraped', function() {
      user = new User({
        id: 'NJ88445',
        roles: ['REPORT_OWNER', 'SERV_DELIVER', 'ADMIN'],
        language: 'en_US',
        timezone: 'US/Eastern',
        ctoken: 'emllbW5pYWs=',
        brand: 'BBH'
      });

      var expected = {
        id: 'NJ88445',
        name: ''
      };

      assert.deepEqual(user.toJSON(), expected);
    });

    it('has only id and name when fully bootstraped', function() {
      user = new User({
        id: 'NJ88445',
        roles: ['REPORT_OWNER', 'SERV_DELIVER', 'ADMIN'],
        language: 'en_US',
        timezone: 'US/Eastern',
        ctoken: 'emllbW5pYWs=',
        brand: 'BBH'
      });

      user.setExternalResources({
        "portalUrl": "https://rdwebportal.bbh.com/bbh/portal",
        "schedulingAppUrl": "https://rdweb.bbh.com",
        "reportingAppUrl": "https://rdreporting.bbh.com"
      });

      var expected = {
        id: 'NJ88445',
        name: ''
      };

      assert.deepEqual(user.toJSON(), expected);
    });
  });

});
