var ReportType = require('../../../../../src/main/js/models/criteria/reportType');

var chai = require('chai');
var expect = chai.expect;

describe('ReportType', function () {

  var reportType;
  var VALID_FILTER = ['A', 'B'];

  beforeEach(function () {
    reportType = new ReportType({
      'id': 'reportTypeCategory'
    });
  });

  it('is valid when created', function () {
    expect(reportType.isValid()).to.be.true;
  });

  it('has no filter set when created', function () {
    expect(reportType.isFilterSet()).to.be.false;
  });

  describe('setting filter', function () {

    it('has filter set with valid filter value', function () {
      reportType.setFilter(VALID_FILTER);
      expect(reportType.isFilterSet()).to.be.true;
    });

    it('has matching filter value', function () {
      reportType.setFilter(VALID_FILTER);
      expect(reportType.get('filter')).to.deep.equal(VALID_FILTER);
    });

    it('has no filter set when set with a string', function () {
      reportType.setFilter('A');
      expect(reportType.isFilterSet()).to.be.false;
    });

    it('has no filter set when set with empty array', function () {
      reportType.setFilter([]);
      expect(reportType.isFilterSet()).to.be.false;
    });

  });

  describe('query generation', function () {

    it('returns correct query for valid filter', function () {
      reportType.setFilter(VALID_FILTER);
      expect(reportType.toQuery()).to.eql({
        'reportTypeCategory': {
          '$in': VALID_FILTER
        }
      });
    });

  });
});
