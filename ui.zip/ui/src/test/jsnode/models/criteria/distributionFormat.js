var DistributionFormat = require('../../../../../src/main/js/models/criteria/distributionFormat');

var chai = require('chai');
var expect = chai.expect;

describe('DistributionFormat', function () {

  var distributionFormat;

  beforeEach(function () {
    distributionFormat = new DistributionFormat({
      'id': 'distributionFormat'
    });
  });

  it('is not sortable', function () {
    var sortable = distributionFormat.get('isSortable');
    expect(sortable).to.be.false;
  });

  it('is valid when created', function () {
    expect(distributionFormat.isValid()).to.be.true;
  });

  describe('isFilterSet', function () {

    it('is not set when created', function () {
      expect(distributionFormat.isFilterSet()).is.false;
    });

    it('is set when set with an array', function () {
      var val = ['abc'];
      distributionFormat.setFilter(val);
      expect(distributionFormat.isFilterSet()).is.true;
    });

    it('is not set when set with an empty array', function () {
      distributionFormat.setFilter([]);
      expect(distributionFormat.isFilterSet()).is.false;
    });

    it('is not set when set with null', function () {
      distributionFormat.setFilter(null);
      expect(distributionFormat.isFilterSet()).is.false;
    });

    it('is not set when set with object', function () {
      distributionFormat.setFilter({a: 1});
      expect(distributionFormat.isFilterSet()).is.false;
    });

    it('is not set when set with string', function () {
      distributionFormat.setFilter('abc');
      expect(distributionFormat.isFilterSet()).is.false;
    });

  });

  describe('query generation', function () {

    it('returns query object when filter set with multiple options', function () {
      distributionFormat.setFilter(['Link', 'FTP']);
      var query = distributionFormat.toQuery();

      expect(query).to.eql({
        '$or': [{
          'deliveryIndicatorLink': {
            '$eq': 'Y'
          }
        }, {
          'deliveryIndicatorFTP': {
            '$eq': 'Y'
          }
        }]
      });
    });

    it('returns query object when filter set with single option', function () {
      distributionFormat.setFilter(['Link']);
      var query = distributionFormat.toQuery();

      expect(query).to.eql({
        'deliveryIndicatorLink': {
          '$eq': 'Y'
        }
      });
    });
  });
});
