var Criterion = require('../../../../../src/main/js/models/criteria/criterion');
var Criteria = require('../../../../../src/main/js/collections/criteria');

var chai = require('chai');
var expect = chai.expect;

describe('Criterion', function () {

  describe('A single criterion without collection', function () {

    var field;

    beforeEach(function () {
      field = new Criterion({
        id: 'reportName'
      });
    });

    it('matches the id', function () {
      expect(field.get('id')).to.equal('reportName');
    });

    it('is not a sort field by default', function () {
      var isSort = field.isSortField();
      expect(isSort).to.be.false;
    });

    it('is sortable by default', function () {
      expect(field.isSortable()).to.be.true;
    });

    it('is set to not sortable', function () {
      var notSortableField = new Criterion({
        id: 'reportName',
        isSortable: false
      });

      expect(notSortableField.isSortable()).to.be.false;
    });

    it('is not sortable when is group field', function () {
      field.toggleGroupField();
      expect(field.isSortable()).to.be.false;
    });

    it('is set as sort field', function () {
      field.makeSortField();
      expect(field.isSortField()).to.be.true;
    });

    it('has asc order the first time', function () {
      field.makeSortField();
      expect(field.isAscendingSort()).to.be.true;
    });

    it('has desc order on second call', function () {
      field.makeSortField();
      field.makeSortField();
      expect(field.get('sortOrder')).to.equal(-1);
    });

    it('returns sort object', function () {
      field.makeSortField();
      expect(field.toSortBy()).to.eql({
        'field': 'reportName',
        'order': 1
      });
    });

    it('returns group object', function () {
      field.toggleGroupField();
      expect(field.toGroupBy()).to.eql({
        'field': 'reportName',
        'order': 1
      });
    });

    it('never produces a query string', function () {
      expect(field.toQuery()).to.be.null;
    });
  });

  describe('In a criteria collection', function () {
    var foo, bar, fiz, buz;
    var criteria;

    beforeEach(function () {
      criteria = new Criteria();

      foo = new Criterion({
        name: 'foo'
      });
      criteria.add(foo);

      bar = new Criterion({
        name: 'bar'
      });
      criteria.add(bar);

      fiz = new Criterion({
        name: 'fiz'
      });
      criteria.add(fiz);

      buz = new Criterion({
        name: 'buz'
      });
      criteria.add(buz);
    });

    it('matches the names', function () {
      expect(foo.get('name')).to.equal('foo');
      expect(bar.get('name')).to.equal('bar');
      expect(fiz.get('name')).to.equal('fiz');
      expect(buz.get('name')).to.equal('buz');
    });

    it('is not a sort field by default', function () {
      var isSort = foo.isSortField();
      expect(isSort).to.be.false;
    });

    it('is set as sort field', function () {
      foo.makeSortField();
      expect(foo.isSortField()).to.be.true;
    });

    it('is sortable by default', function () {
      expect(foo.isSortable()).to.be.true;
    });

    it('is set to not sortable', function () {
      var notSortableField = new Criterion({
        id: 'notSortableName',
        isSortable: false
      });
      criteria.add(notSortableField);

      expect(notSortableField.isSortable()).to.be.false;
    });

    it('is not sortable when is group field', function () {
      foo.toggleGroupField();
      expect(foo.isSortable()).to.be.false;
    });

    it('has asc order', function () {
      fiz.makeSortField();
      expect(fiz.isAscendingSort()).to.be.true;
    });

    it('triggers change event', function () {
      var changed = false;
      fiz.on('change', function () {
        changed = true;
      });
      fiz.makeSortField();
      expect(changed).to.be.true;
    });

    it('has desc order on second call', function () {
      buz.makeSortField();
      buz.makeSortField();

      expect(buz.get('sortOrder')).to.equal(-1);
    });

    it('has second criterion as sort field', function () {
      foo.makeSortField();
      buz.makeSortField();

      expect(foo.isSortField()).to.be.false;
      expect(buz.isSortField()).to.be.true;
      expect(buz.get('sortOrder')).to.equal(1);
    });

    it('triggers change event for previous sort field', function () {
      foo.makeSortField();

      var fooChanged = false;
      foo.on('change', function () {
        fooChanged = true;
      });

      buz.makeSortField();

      expect(fooChanged).to.be.true;
    });

    it('is set as a group field', function () {
      foo.toggleGroupField();
      expect(foo.isGroupField()).to.be.true;
    });

    it('is unset as a group field when toggled twice', function () {
      foo.toggleGroupField();
      expect(foo.isGroupField()).to.be.true;
      foo.toggleGroupField();
      expect(foo.isGroupField()).to.be.false;
    });

    it('cannot sort on a field if it is already a group by field', function () {
      bar.toggleGroupField();
      bar.makeSortField();
      expect(bar.isGroupField()).to.be.true;
      expect(bar.isSortField()).to.be.false;
    });

    it('removes sort order when a field is made group field', function () {
      bar.makeSortField();
      bar.toggleGroupField();
      expect(bar.isGroupField()).to.be.true;
      expect(bar.isSortField()).to.be.false;
    });
  });

  describe('Validation', function () {
    var criterion;

    beforeEach(function () {
      criterion = new Criterion();
    });

    it('has invalid filter when filter is undefined', function () {
      criterion.set('filter', undefined);
      expect(criterion.isFilterSet()).to.be.false;
    });

    it('has invalid filter when filter is null', function () {
      criterion.set('filter', null);
      expect(criterion.isFilterSet()).to.be.false;
    });

    it('has invalid filter when filter is empty string', function () {
      criterion.set('filter', '');
      expect(criterion.isFilterSet()).to.be.false;
    });

    it('has invalid filter when filter is an empty array', function () {
      criterion.set('filter', []);
      expect(criterion.isFilterSet()).to.be.false;
    });

    it('has valid filter when filter is object', function () {
      criterion.set('filter', {});
      expect(criterion.isFilterSet()).to.be.true;
    });

    it('has valid filter when filter is non-empty string', function () {
      criterion.set('filter', 'abc');
      expect(criterion.isFilterSet()).to.be.true;
    });

    it('has valid filter when filter is a number', function () {
      criterion.set('filter', 123);
      expect(criterion.isFilterSet()).to.be.true;
    });

    it('has valid filter when filter is an array', function () {
      criterion.set('filter', [123]);
      expect(criterion.isFilterSet()).to.be.true;
    });

    it('has valid filter when filter is date', function () {
      criterion.set('filter', new Date());
      expect(criterion.isFilterSet()).to.be.true;
    });
  });
});
