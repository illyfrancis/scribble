var ReportCategory = require('../../../../../src/main/js/models/criteria/reportCategory');
var Criteria = require('../../../../../src/main/js/collections/criteria');

var chai = require('chai');
var expect = chai.expect;

describe('ReportCategory', function () {

  var criteria;

  beforeEach(function () {
    criteria = new Criteria();
  });

  it('has no filter set when created', function () {
    var reportCategory = new ReportCategory({
      'id': 'reportCategory'
    });

    expect(reportCategory.isFilterSet()).to.be.false;
  });

  it('has filter set when report type filter within collection is set', function () {
    criteria.get('reportType').set('filter', 'abc');

    expect(criteria.get('reportCategory').isFilterSet()).to.be.true;
  });

  it('has no filter set when within a collection that is missing report type', function () {
    var reportType = criteria.get('reportType');
    reportType.set('filter', 'abc');
    criteria.remove(reportType);

    expect(criteria.get('reportCategory').isFilterSet()).to.be.false;
  });
});
