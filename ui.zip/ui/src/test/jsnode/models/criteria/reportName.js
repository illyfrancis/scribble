var ReportName = require('../../../../../src/main/js/models/criteria/reportName');

var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');

describe('ReportName', function () {

  var reportName;

  beforeEach(function () {
    reportName = new ReportName({
      'id': 'reportName'
    });
  });

  describe('On creation', function () {

    it('is valid', function () {
      expect(reportName.isValid()).to.be.true;
    });

    it('has no filter set', function () {
      expect(reportName.isFilterSet()).to.be.false;
    });

  });

  describe('Setting filter', function () {

    it('has no validation error and set the filter ', function () {
      reportName.setFilter('TRANSACT');

      expect(reportName.validationError).to.be.null;
      expect(reportName.get('filter')).to.equal('TRANSACT');
    });

    it('has filter set when set with valid value', function () {
      reportName.setFilter('TRANSACT');
      expect(reportName.isFilterSet()).to.be.true;
    });

    it('retains filter value when setting same value twice', function () {
      sinon.spy(reportName, 'validate');

      var filterValue = 'TRANSACT';
      reportName.setFilter(filterValue);
      reportName.setFilter(filterValue);

      expect(reportName.get('filter')).to.equal(filterValue);
      expect(reportName.validate.calledOnce).to.be.true;
    });

    it('fails validation when filter value is too long', function () {
      var LONG_FILTER_VAL = 'This is text that has more than 40 characters';
      reportName.setFilter(LONG_FILTER_VAL);

      expect(reportName.validationError).to.equal('value specified cannot be longer than 40 characters');
    });

    it('triggers "change" event when set with setFilter', function () {
      var spy = sinon.spy();
      reportName.on('change', spy);
      reportName.setFilter('TRANSACT');

      sinon.assert.calledOnce(spy); // or expect(spy.called).is.false;
    });

  });

  describe('Query generation', function () {

    it('returns query object when filter set', function () {
      reportName.setFilter('TRANSACT');
      var query = reportName.toQuery();

      expect(query).to.eql({
        'reportName': {
          '$containsIgnoreCase': 'TRANSACT'
        }
      });
    });

  });

});
