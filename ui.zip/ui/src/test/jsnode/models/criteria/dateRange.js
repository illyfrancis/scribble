var DateRange = require('../../../../../src/main/js/models/criteria/dateRange');

var chai = require('chai');
var expect = chai.expect;
var moment = require('moment-timezone');

describe('DateRange', function () {

  var dateRange;
  var fromDate = new Date(1);
  var toDate = new Date(2);
  var options;

  beforeEach(function () {
    dateRange = new DateRange({
      'id': 'dateRangeField'
    });

    options = {
      timezone: 'Australia/Sydney'
    };
  });

  it('is valid when created', function () {
    expect(dateRange.isValid()).to.be.true;
  });

  describe('Parsing', function () {
    it('parses date values in response correctly', function () {

      var response = {
        filter: {
          from: '1970-01-01T00:00:00.001Z',
          to: '1970-01-01T00:00:00.002Z'
        }
      };

      var parsedResponse = dateRange.parse(response);

      expect(parsedResponse).to.be.deep.equal({
        filter: {
          from: fromDate,
          to: toDate
        }
      });
    });

    it('parses response correctly when filter only contains the from portion of the date range', function () {

      var response = {
        filter: {
          from: '1970-01-01T00:00:00.001Z'
        }
      };

      var parsedResponse = dateRange.parse(response);

      expect(parsedResponse).to.be.deep.equal({
        filter: {
          from: fromDate
        }
      });
    });

    it('parses response correctly when filter only contains the to portion of the date range', function () {

      var response = {
        filter: {
          to: '1970-01-01T00:00:00.002Z'
        }
      };

      var parsedResponse = dateRange.parse(response);

      expect(parsedResponse).to.be.deep.equal({
        filter: {
          to: toDate
        }
      });
    });

    it('can parse response that has a null filter', function () {
      var response = {
        filter: null
      };
      var parsedResponse = dateRange.parse(response);

      expect(parsedResponse).to.eql(response);
    });
  });

  describe('Setting individual dates', function () {

    it('succeeds when setting *from* date', function () {
      dateRange.setFilter({
        from: null,
        to: null
      });

      dateRange.setFromDate(fromDate);

      expect(dateRange.get('filter')).to.be.deep.equal({
        from: fromDate,
        to: null
      });
    });

    it('succeeds when setting *from* date while filter is null', function () {
      dateRange.set('filter', null);

      dateRange.setFromDate(fromDate);

      expect(dateRange.get('filter')).to.be.deep.equal({
        from: fromDate,
        to: null
      });
    });

    it('succeeds when setting *to* date', function () {
      dateRange.setFilter({
        from: null,
        to: null
      });

      dateRange.setToDate(toDate);

      expect(dateRange.get('filter')).to.be.deep.equal({
        from: null,
        to: toDate
      });
    });

    it('succeeds when setting *to* date while filter is null', function () {
      dateRange.set('filter', null);

      dateRange.setToDate(toDate);

      expect(dateRange.get('filter')).to.be.deep.equal({
        from: null,
        to: toDate
      });
    });
  });

  describe('Setting filter', function () {

    it('has no validation error and sets the filter when dates are correct', function () {

      dateRange.setFilter({
        from: fromDate,
        to: toDate
      });

      expect(dateRange.validationError).to.be.null;
      expect(dateRange.get('filter')).to.be.deep.equal({
        from: fromDate,
        to: toDate
      });
    });

    it('has no validation error and set the filter when both dates are null', function () {

      dateRange.setFilter({
        from: null,
        to: null
      });

      expect(dateRange.validationError).to.be.null;
      expect(dateRange.get('filter')).to.be.deep.equal({
        from: null,
        to: null
      });
    });

    it('fails validation when *from* date is after *to* date', function () {

      dateRange.setFilter({
        from: new Date(3),
        to: toDate
      });

      expect(dateRange.validationError).to.equal('From date can\'t be after the To date');
    });
  });

  describe('Query generation', function () {

    var fromDate, toDate;
    var formatDate = function (moment) {
      return moment.toISOString().replace(/\..*Z/, 'Z');
    };

    it('returns a null object when no filter value set', function () {
      var query = dateRange.toQuery(options);
      expect(query).to.be.null;
    });

    it('returns correct query object when both dates are set in filter', function () {

      dateRange.setFilter({
        from: fromDate,
        to: toDate
      });

      var query = dateRange.toQuery(options);

      var expectedFromDate = moment.tz(moment(fromDate).format('YYYY-MM-DD'), options.timezone).startOf('day');
      var expectedToDate = moment.tz(moment(toDate).format('YYYY-MM-DD'), options.timezone).endOf('day');

      expect(query).to.be.deep.equal({
        '$and': [{
          'dateRangeField': {
            '$gte': {
              '$date': formatDate(expectedFromDate)
            }
          }
        }, {
          'dateRangeField': {
            '$lte': {
              '$date': formatDate(expectedToDate)
            }
          }
        }]
      });
    });

    it('returns correct query object when only *from* date is set in filter', function () {

      dateRange.setFilter({
        from: fromDate,
        to: null
      });

      var query = dateRange.toQuery(options);

      var expectedFromDate = moment.tz(moment(fromDate).format('YYYY-MM-DD'), options.timezone).startOf('day');

      expect(query).to.be.deep.equal({
        'dateRangeField': {
          '$gte': {
            '$date': formatDate(expectedFromDate)
          }
        }
      });
    });

    it('returns correct query object when only *to* date is set in filter', function () {

      dateRange.setFilter({
        from: null,
        to: toDate
      });

      var query = dateRange.toQuery(options);

      var expectedToDate = moment.tz(moment(toDate).format('YYYY-MM-DD'), options.timezone).endOf('day');

      expect(query).to.be.deep.equal({
        'dateRangeField': {
          '$lte': {
            '$date': formatDate(expectedToDate)
          }
        }
      });
    });

    it('uses current date for query when no timezone provided', function () {

      dateRange.setFilter({
        from: fromDate,
        to: null
      });

      var query = dateRange.toQuery();

      var expectedFromDate = moment().startOf('day');

      expect(query).to.be.deep.equal({
        'dateRangeField': {
          '$gte': {
            '$date': formatDate(expectedFromDate)
          }
        }
      });
    });
  });
});
