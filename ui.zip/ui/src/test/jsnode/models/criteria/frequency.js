var Frequency = require('../../../../../src/main/js/models/criteria/frequency');

var chai = require('chai');
var expect = chai.expect;

describe('Frequency', function () {

  var frequency;
  var VALID_FILTER = ['DAILY', 'WEEKLY'];

  beforeEach(function () {
    frequency = new Frequency({
      'id': 'frequency'
    });
  });

  it('is valid when created', function () {
    expect(frequency.isValid()).to.be.true;
  });

  it('is able to convert selected options to uppercase', function () {
    var converted = frequency.transform(['aAa', 'AaA']);
    expect(converted).to.be.eql(['AAA', 'AAA']);
  });

  describe('setting filter', function () {

    it('has filter set with valid filter value', function () {
      frequency.setFilter(VALID_FILTER);
      expect(frequency.isFilterSet()).to.be.true;
    });

    it('has matching filter value', function () {
      frequency.setFilter(VALID_FILTER);
      expect(frequency.get('filter')).to.deep.equal(VALID_FILTER);
    });

    it('has no filter set when set with a string', function () {
      frequency.setFilter('A');
      expect(frequency.isFilterSet()).to.be.false;
    });

    it('has no filter set when set with empty array', function () {
      frequency.setFilter([]);
      expect(frequency.isFilterSet()).to.be.false;
    });

  });

  describe('query generation', function () {

    it('returns query object when filter set', function () {
      frequency.setFilter(['daily', 'weekly']);
      var query = frequency.toQuery();

      expect(query).to.eql({
        'frequency': {
          '$in': ['DAILY', 'WEEKLY']
        }
      });
    });

  });
});
