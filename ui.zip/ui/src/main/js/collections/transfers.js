var Backbone = require('backbone');
var Transfer = require('../models/transfer');

var Transfers = Backbone.Collection.extend({

  transferUrl: './api/transfers/{direction}/{userId}',
  // transferUrl: './api/transfers?{direction}={userId}',

  userId: 'none',

  direction: 'incoming',

  model: Transfer,

  initialize: function (models, options) {
    if (options && options.userId && options.direction) {
      this.userId = options.userId;
      this.direction = options.direction;
    }
  },

  url: function () {
    return this.transferUrl.replace('{userId}', this.userId).replace('{direction}', this.direction === 'outgoing' ? 'from' : 'to');
  },

  parse: function (response) {
    return response.transfers;
  },

  applySort: function (sortField, sortOrder) {
    this.comparator = function (a, b) {
      return sortOrder * a.get(sortField).localeCompare(b.get(sortField));
    };

    this.sort();
  },

  load: function () {
    return this.fetch({
      reset: true
    });
  }

});

module.exports = Transfers;
