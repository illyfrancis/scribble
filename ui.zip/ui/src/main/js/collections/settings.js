var _ = require('underscore');
var Client = require('../models/criteria/client');
var CreatedBy = require('../models/criteria/user');
var DistributionFormat = require('../models/criteria/distributionFormat');
var DistributionList = require('../models/criteria/distributionList');
var Frequency = require('../models/criteria/frequency');
var LastExecution = require('../models/criteria/lastExecution');
var ModifiedBy = require('../models/criteria/user');
var ReportCategory = require('../models/criteria/reportCategory');
var ReportExpiry = require('../models/criteria/reportExpiry');
var ReportName = require('../models/criteria/reportName');
var ReportOwner = require('../models/criteria/reportOwner');
var ReportType = require('../models/criteria/reportType');

var settings = {
  // criteria defaults
  defaults: function () {
    return [
      new Client({
        'id': 'clients',
        'filterWith': 'clientId',
        'sortWith': 'clientId',
        'title': 'Client',
        'displayOrder': 10
      }),
      new CreatedBy({
        'id': 'createdBy',
        'filterWith': 'createdById',
        'sortWith': 'createdByName',
        'title': 'Created by',
        'displayOrder': 4
      }),
      new DistributionFormat({
        'id': 'distributionFormat',
        'title': 'Delivery',
        'displayOrder': 9
      }),
      new DistributionList({
        'id': 'distributionList',
        'title': 'Distribution list',
        'displayOrder': 7
      }),
      new Frequency({
        'id': 'frequency',
        'title': 'Frequency',
        'displayOrder': 6
      }),
      new LastExecution({
        'id': 'lastExecution',
        'title': 'Last execution',
        'displayOrder': 8
      }),
      new ModifiedBy({
        'id': 'modifiedBy',
        'filterWith': 'modifiedById',
        'sortWith': 'modifiedByName',
        'title': 'Modified by',
        'displayOrder': 5
      }),
      new ReportCategory({
        'id': 'reportCategory',
        'filterWith': 'reportCategoryId',
        'sortWith': 'reportCategory',
        'title': 'Report category',
        'displayOrder': 1
      }),
      new ReportExpiry({
        'id': 'reportExpiry',
        'title': 'Report expiry',
        'displayOrder': 11
      }),
      new ReportName({
        'id': 'reportName',
        'title': 'Report name',
        'displayOrder': 0
      }),
      new ReportOwner({
        'id': 'reportOwner',
        'filterWith': 'reportOwnerId',
        'sortWith': 'reportOwnerName',
        'title': 'Report owner',
        'displayOrder': 3,
        'groupOrder': 1
      }),
      new ReportType({
        'id': 'reportType',
        'filterWith': 'reportTypeCode',
        'sortWith': 'reportType',
        'title': 'Report type',
        'displayOrder': 2
      })
    ];
  },

  transfers: {
    defaultFilters: function () {
      var status = ['PENDING', 'ACCEPTED', 'REJECTED', 'CANCELLED', 'EXPIRED'];
      return _.map(status, function (s) {
        return {
          'status': s,
          'applied': s === 'PENDING'
        };
      });
    },

    incomingHeaders: function () {
      return [{
        id: 'reportName',
        title: 'Report name'
      }, {
        id: 'reportOwner',
        title: 'Report owner',
        sortWith: 'reportOwnerName'
      }, {
        id: 'status',
        title: 'Transfer status'
      }, {
        id: 'requestedOn',
        title: 'Requested'
      }, {
        id: 'initiator',
        title: 'Requested by',
        sortWith: 'initiatorName'
      }, {
        id: 'requestExpiry',
        title: 'Request expires'
      }, {
        id: 'approval',
        title: 'Approval',
        isSortable: false
      }];
    },

    outgoingHeaders: function () {
      return [{
        id: 'reportName',
        title: 'Report name'
      }, {
        id: 'reportOwner',
        title: 'Report owner',
        sortWith: 'reportOwnerName'
      }, {
        id: 'status',
        title: 'Transfer status'
      }, {
        id: 'requestedOn',
        title: 'Requested'
      }, {
        id: 'initiator',
        title: 'Requested by',
        sortWith: 'initiatorName'
      }, {
        id: 'requestExpiry',
        title: 'Request expires'
      }, {
        id: 'cancel',
        title: 'Cancel',
        isSortable: false
      }];
    }
  }

};

module.exports = settings;
