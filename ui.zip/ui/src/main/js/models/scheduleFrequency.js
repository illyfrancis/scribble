var Backbone = require('backbone');
var _ = require('underscore');
_.str = require('underscore.string');
var moment = require('moment');

var ScheduleFrequency = Backbone.Model.extend({
  defaults: {
    absMonth: null,
    absMonthDay: null,
    dailyPeriod: null,
    frequency: null,
    intradayEndTime: null,
    intradayInterval: null,
    intradayPeriod: null,
    intradayStartTime: null,
    relativeMonth: null,
    relativeWeek: null,
    relativeWeekDay: null,
    scheduleType: null,
    startTime: null,
    weekDay: null,
    weekDaysOnly: null,
  },

  intervals: {
    'MINUTE': 'minute(s)',
    'HOUR': 'hour(s)',
    'DAY': 'day(s)'
  },

  types: {
    'DAILY': 'days',
    'WEEKLY': 'weeks',
    'MONTHLY': 'months'
  },

  daysOfWeek: ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'],

  formatDetail: function () {
    return this.shouldFormatDetail() ? this.doFormatDetail() : '';
  },

  shouldFormatDetail: function () {
    var scheduleType = this.get('scheduleType');
    return scheduleType === 'DAILY' || scheduleType === 'WEEKLY' || scheduleType === 'MONTHLY';
  },

  doFormatDetail: function () {
    var result;

    result = this.convertType();
    result = this.convertStartTime(result);
    result = this.convertRange(result);
    result = this.convertDetails(result);
    result = this.convertFrequency(result);

    return result;
  },

  convertType: function () {
    return _.str.titleize(this.get('scheduleType'));
  },

  convertStartTime: function (partialResult) {
    return partialResult + ' starting at ' + this.convertTime(this.get('startTime'));
  },

  convertTime: function (time) {
    return moment(time, 'HH:mm', true).format('h:mma');
  },

  convertRange: function (partialResult) {
    var intradayStartTime = this.get('intradayStartTime');
    if (_.isUndefined(intradayStartTime) || _.isNull(intradayStartTime)) {
      return partialResult;
    }

    return partialResult +
      ' between ' + this.convertTime(intradayStartTime) +
      ' and ' + this.convertTime(this.get('intradayEndTime')) +
      ' every ' + this.get('intradayInterval') +
      ' ' + this.convertReccurencePeriod(this.get('intradayPeriod'));
  },

  convertReccurencePeriod: function (period) {
    return this.intervals[period];
  },

  convertDetails: function (partialResult) {
    if (this.get('scheduleType') === 'WEEKLY') {
      return this.convertWeeklyDetails(partialResult);
    }

    if (this.get('scheduleType') === 'MONTHLY') {
      return this.convertMonthlyDetails(partialResult);
    }

    return partialResult;
  },

  convertWeeklyDetails: function (partialResult) {
    var weekDay = this.get('weekDay');
    if (_.isUndefined(weekDay) || _.isNull(weekDay)) {
      return partialResult;
    }

    var self = this;

    var sortByDay = function (day) {
      return _.indexOf(self.daysOfWeek, day);
    };

    var capitalizeDay = function (day) {
      return _.str.titleize(day);
    };

    var weekDays = _.chain(weekDay.split(',')).sortBy(sortByDay).map(capitalizeDay).value().join(', ');

    return partialResult + ' on ' + weekDays;
  },

  convertMonthlyDetails: function (partialResult) {
    var absMonthDay = this.get('absMonthDay');
    if (!_.isUndefined(absMonthDay) && !_.isNull(absMonthDay)) {
      return this.convertAbsoluteMonthDay(partialResult);
    } else {
      return this.convertNonAbsoluteMonthDay(partialResult);
    }
  },

  convertAbsoluteMonthDay: function (partialResult) {
    var absMonthDay = this.get('absMonthDay');
    return partialResult +
      ' on ' + this.convertDayNumber(Math.abs(absMonthDay)) +
      ' ' + (this.get('weekDaysOnly') ? 'business' : 'calendar') +
      ' day' + (absMonthDay > 0 ? ' after' : ' before') +
      ' month end';
  },

  convertDayNumber: function (dayNumber) {
    switch (dayNumber) {
    case 1:
    case 21:
    case 31:
      return dayNumber + "st";
    case 2:
    case 22:
      return dayNumber + "nd";
    case 3:
    case 23:
      return dayNumber + "rd";
    default:
      return dayNumber + "th";
    }
  },

  convertNonAbsoluteMonthDay: function (partialResult) {
    var relativeWeek = this.get('relativeWeek');
    var relativeWeekDay = this.get('relativeWeekDay');

    if (_.isUndefined(relativeWeek) || _.isNull(relativeWeek) || _.isUndefined(relativeWeekDay) || _.isNull(relativeWeekDay)) {
      return partialResult;
    }

    return partialResult +
      ' on ' + relativeWeek.toLowerCase() +
      ' ' + _.str.titleize(relativeWeekDay);
  },

  convertFrequency: function (partialResult) {
    var frequency = this.get('frequency');
    if (_.isUndefined(frequency) || _.isNull(frequency) || frequency <= 1) {
      return partialResult;
    }

    if (this.get('scheduleType') === 'DAILY') {
      return partialResult + ' every ' + frequency + ' ' + this.convertReccurencePeriod(this.get('dailyPeriod'));
    } else {
      return partialResult + ' every ' + frequency + ' ' + this.convertFrequencyType(this.get('scheduleType'));
    }
  },

  convertFrequencyType: function (type) {
    return this.types[type];
  },

  formatWeekDays: function () {
    if (this.get('scheduleType') !== 'WEEKLY') {
      return '';
    }

    var self = this;

    var sortByDay = function (day) {
      return _.indexOf(self.daysOfWeek, day);
    };

    var mapDay = function (day) {
      if (day === 'THURSDAY' || day === 'SATURDAY') {
        return day.substr(0, 2);
      } else {
        return day.charAt(0);
      }
    };

    var weekDay = this.get('weekDay');
    return _.chain(weekDay.split(',')).sortBy(sortByDay).map(mapDay).value().join(' ');
  }
});

module.exports = ScheduleFrequency;
