var _ = require('underscore');
_.str = require('underscore.string');
var Criterion = require('./criterion');

var User = Criterion.extend({

  initialize: function () {
    this.set('filter', null);
  },

  validate: function (attrs) {
    var filter = attrs.filter;
    if (!_.isNull(filter)) {
      if (filter.length > 30) {
        return 'value specified cannot be longer than 30 characters';
      }

      if (!/^[a-z0-9]*$/i.test(filter)) {
        return 'value specified must be alpha-numeric characters only';
      }
    }
  },

  setFilter: function (filter) {
    filter = _.escape(_.str.trim(filter));
    if (this.get('filter') !== filter) {
      this.set('filter', filter, {
        validate: true
      });
    }
  },

  toQuery: function () {
    var filter = this.get('filter');
    var query = {};
    query[this.filterWith()] = {
      '$eqIgnoreCase': filter
    };

    return query;
  }

});

module.exports = User;
