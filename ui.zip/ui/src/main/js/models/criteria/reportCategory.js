var Criterion = require('./criterion');

var ReportCategory = Criterion.extend({

  isFilterSet: function () {
    var isReportTypeSet = false;
    if (this.collection) {
      var reportType = this.collection.get('reportType');
      if (reportType) {
        isReportTypeSet = reportType.isFilterSet();
      }
    }

    return isReportTypeSet;
  }

});

module.exports = ReportCategory;
