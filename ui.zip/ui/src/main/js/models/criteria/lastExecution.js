var DateRange = require('./dateRange');

var LastExecution = DateRange.extend();

module.exports = LastExecution;
