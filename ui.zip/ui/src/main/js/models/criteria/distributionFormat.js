var _ = require('underscore');
var MultiSelect = require('./multiSelect');

var DistributionFormat = MultiSelect.extend({

  initialize: function () {
    this.set('isSortable', false);
  },

  toQuery: function () {
    var query = null;
    var filter = this.get('filter');
    var queries = this.transform(filter);

    if (queries.length > 1) {
      query = {
        '$or': queries
      };
    } else {
      query = queries.shift();
    }

    return query;
  },

  transform: function (filter) {
    return _.map(filter, this.selectedElementToQueryCondition);
  },

  selectedElementToQueryCondition: function (element) {
    var obj = {};
    obj['deliveryIndicator' + element] = {
      '$eq': 'Y'
    };

    return obj;
  }
});

module.exports = DistributionFormat;
