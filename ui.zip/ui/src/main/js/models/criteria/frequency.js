var _ = require('underscore');
var MultiSelect = require('./multiSelect');

var Frequency = MultiSelect.extend({

  transform: function (filter) {
    return _.map(filter, function (element) {
      return element.toUpperCase();
    });
  }

});

module.exports = Frequency;
