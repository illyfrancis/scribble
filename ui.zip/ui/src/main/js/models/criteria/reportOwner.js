var Criterion = require('./criterion');
var Users = require('../../collections/users');

var ReportOwner = Criterion.extend({

  initialize: function () {
    this.users = new Users(this.get('filter'));
    this.listenTo(this.users, 'add remove reset', this.updateFilter);
    this.on('change:filter', this.updateUsers);
  },

  updateUsers: function (model, filter) {
    this.users.reset(filter, {
      silent: true
    });
  },

  updateFilter: function () {
    this.set('filter', this.users.toJSON(), {
      silent: true
    });
  },

  isFilterSet: function () {
    return this.users.length > 0;
  },

  toQuery: function () {
    var query = null;
    var selectedUserIds = this.users.map(function (user) {
      return user.get('id');
    });

    if (selectedUserIds.length === 1) {
      query = {};
      query[this.filterWith()] = {
        '$eq': selectedUserIds.shift()
      };
    } else if (selectedUserIds.length > 1) {
      query = {};
      query[this.filterWith()] = {
        '$in': selectedUserIds
      };
    }

    return query;
  }

});

module.exports = ReportOwner;
