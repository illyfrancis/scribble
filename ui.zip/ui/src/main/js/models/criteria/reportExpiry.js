var DateRange = require('./dateRange');

var ReportExpiry = DateRange.extend();

module.exports = ReportExpiry;
