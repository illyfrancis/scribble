var _ = require('underscore');
var Criterion = require('./criterion');

var MultiSelect = Criterion.extend({

  validate: function (attrs) {
    if (!_.isNull(attrs.filter) && !_.isArray(attrs.filter)) {
      return 'invalid filter value';
    }
  },

  setFilter: function (filter) {
    this.set('filter', filter, {
      validate: true
    });
  },

  toQuery: function () {
    var filter = this.get('filter');
    var query = {};
    query[this.filterWith()] = {
      '$in': this.transform(filter)
    };

    return query;
  },

  transform: function (filter) {
    return filter;
  }

});

module.exports = MultiSelect;
