var MultiSelect = require('./multiSelect');

var ReportType = MultiSelect.extend();

module.exports = ReportType;
