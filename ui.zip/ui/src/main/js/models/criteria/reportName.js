var _ = require('underscore');
_.str = require('underscore.string');
var Criterion = require('./criterion');

var ReportName = Criterion.extend({

  validate: function (attrs) {
    var filter = attrs.filter;
    if (!_.isNull(filter) && filter.length > 40) {
      return 'value specified cannot be longer than 40 characters';
    }
  },

  setFilter: function (filter) {
    filter = _.escape(_.str.trim(filter));
    if (this.get('filter') !== filter) {
      this.set('filter', filter, {
        validate: true
      });
    }
  },

  toQuery: function () {
    var filter = this.get('filter');
    var query = {};
    query[this.filterWith()] = {'$containsIgnoreCase': filter};

    return query;
  }

});

module.exports = ReportName;
