var _ = require('underscore');
_.str = require('underscore.string');
var Criterion = require('./criterion');

var DistributionList = Criterion.extend({

  validate: function (attrs) {
    var filter = attrs.filter;
    if (!_.isNull(filter)) {
      if (filter.length > 100) {
        return 'value specified cannot be longer than 100 characters';
      }
    }
  },

  setFilter: function (filter) {
    filter = _.escape(_.str.trim(filter));
    if (this.get('filter') !== filter) {
      this.set('filter', filter, {
        validate: true
      });
    }
  },

  toQuery: function () {
    var filter = this.get('filter');
    var query = {};
    query[this.filterWith()] = {
      '$containsIgnoreCase': filter
    };

    return query;
  }

});

module.exports = DistributionList;
