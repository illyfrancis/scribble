var Criterion = require('./criterion');
var _ = require('underscore');
var moment = require('moment-timezone');

var DateRange = Criterion.extend({

  initialize: function () {
    this.set('filter', {
      from: null,
      to: null
    });
  },

  parse: function (response) {
    var filter = response.filter;
    if (!_.isNull(filter)) {
      if (this.hasValue(filter.from)) {
        filter.from = this.parseDate(filter.from);
      }
      if (this.hasValue(filter.to)) {
        filter.to = this.parseDate(filter.to);
      }
    }

    return response;
  },

  parseDate: function (date) {
    return moment(date, 'YYYY-MM-DDTHH:mm:ss.SSSZ', true).toDate();
  },

  setFromDate: function (fromDate) {
    this.setFilter({
      from: fromDate,
      to: _.isNull(this.getFilter()) ? null : this.getFilter().to
    });
  },

  setToDate: function (toDate) {
    this.setFilter({
      from: _.isNull(this.getFilter()) ? null : this.getFilter().from,
      to: toDate
    });
  },

  setFilter: function (filter) {
    this.set('filter', filter, {
      validate: true
    });
  },

  getFilter: function () {
    return this.get('filter');
  },

  isFilterSet: function () {
    var filter = this.getFilter();
    return !_.isNull(filter) && (this.isValidDate(filter.from) || this.isValidDate(filter.to));
  },

  validate: function (attrs) {
    var filter = attrs.filter;
    if (this.isValidDate(filter.from) && this.isValidDate(filter.to) && (filter.from > filter.to)) {
      return 'From date can\'t be after the To date';
    }
  },

  isValidDate: function (date) {
    return ((this.hasValue(date)) && (!_.isNaN(date.getTime())));
  },

  hasValue: function (value) {
    return (!_.isNull(value) && (!_.isUndefined(value)));
  },

  toQuery: function (options) {
    options || (options = {});
    var timezone = options.timezone || null;

    var filter = this.getFilter();
    var fromDateCondition = this.createQueryFragment(filter.from, '$gte', this.timezoneDate(filter.from, timezone).startOf('day'));
    var toDateCondition = this.createQueryFragment(filter.to, '$lte', this.timezoneDate(filter.to, timezone).endOf('day'));

    return this.buildQueryFromFragments(fromDateCondition, toDateCondition);
  },

  timezoneDate: function (date, tz) {
    return (_.isNull(date) || _.isNull(tz))? moment() : moment.tz(moment(date).format('YYYY-MM-DD'), tz);
  },

  formatZulu: function (moment) {
    return moment.toISOString().replace(/\..*Z/, 'Z');
  },

  createQueryFragment: function (filterValue, operation, moment) {
    var queryValue = this.formatZulu(moment);

    var queryFragment = null;
    if (!_.isNull(filterValue)) {
      var queryOperation = {};
      queryOperation[operation] = {
        '$date': queryValue
      };
      queryFragment = {};
      queryFragment[this.filterWith()] = queryOperation;
    }

    return queryFragment;
  },

  buildQueryFromFragments: function (fromDateCondition, toDateCondition) {
    var query = null;
    if (!_.isNull(fromDateCondition) && !_.isNull(toDateCondition)) {
      query = {
        '$and': [fromDateCondition, toDateCondition]
      };
    } else if (!_.isNull(fromDateCondition)) {
      query = fromDateCondition;
    } else if (!_.isNull(toDateCondition)) {
      query = toDateCondition;
    }

    return query;
  }
});

module.exports = DateRange;
