var Backbone = require('backbone');

var Transfer = Backbone.Model.extend({

  defaults: {
    // id is the transfer id
    scheduleId: '',
    reportName: '',
    reportOwnerId: '',
    reportOwnerName: '',
    requestedOn: '',
    requestExpiry: '',
    initiatorId: '',
    initiatorName: '',
    receiverId: '',
    receiverName: '',
    status: ''
  },

  urlRoot: './api/transfers',

  operations: {
    'accept': '/accept/by/',
    'reject': '/reject/by/',
    'cancel': '/cancel/by/'
  },

  execute: function (command, userId) {
    // to start, check the current status. if it's not in pending state, it makes no sense to accept or reject
    // perhaps it should be in a validator

    var operation = this.operations[command];
    var options = {
      command: command,
      url: this.url() + operation + encodeURIComponent(userId)
    };

    if (operation) {
      this.save({}, options);
    } else {
      this.trigger('error', this, null, options);
    }
  },

  parse: function (response, options) {
    // console.log('parse: response [' + response + '] & options [' + options + ']');
    return response;
  }

});

module.exports = Transfer;
