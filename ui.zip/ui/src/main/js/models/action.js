var Backbone = require('backbone');

var Action = Backbone.Model.extend({

  url: function () {
    return this.url;
  },

  // TODO - refactor so that schedule can execute generation
  runSchedule: function (scheduleId) {
    var self = this;
    this.url = './api/schedules/' + scheduleId + '/run';

    var options = {
      success: function () {
        self.showNotification('Request to run a schedule was sent successfully.', 'info');
      },
      error: function () {
        self.showNotification('Could not send request to run a schedule.', 'danger');
      },
      headers: {
        'X-Schedule-Id': scheduleId
      }
    };

    this.save({}, options);
  },

  showNotification: function (text, type) {
    Backbone.router.trigger('dashboard:notify', text, type);
  },

  // TODO - refactor API so that initiation is part of schedule API
  // e.g. POST /schedules/:id/transfer/to/:userId
  initiateTransfer: function (scheduleId, userId) {
    var self = this;
    this.url = './api/transfers/schedule/' + scheduleId + '/to/' + userId;

    var options = {
      success: function () {
        self.showNotification('Transfer completed successfully', 'info');
      },
      error: function () {
        // TODO - define error object and its content.
        self.showNotification('Could not transfer because ...', 'danger');
      },
      headers: {
        'X-Schedule-Id': scheduleId
      }
    };

    this.save({}, options);
  }

});

module.exports = Action;
