var _ = require('underscore');
var Backbone = require('backbone');
var ScheduleFrequency = require('./scheduleFrequency');

var Schedule = Backbone.Model.extend({
  defaults: {
    clientId: '',
    clientName: '',
    createdById: '',
    createdByName: '',
    distributionFormat: '',
    distributionList: '',
    frequencyDetail: '',
    lastExecution: '',
    lastReportOutputId: '',
    modifiedById: '',
    modifiedByName: '',
    reportCategory: '',
    reportCategoryId: '',
    reportExpiry: '',
    reportName: '',
    reportOwnerId: '',
    reportOwnerName: '',
    reportType: '',
    reportTypeCode: ''
  },

  parse: function (response) {
    response.frequencyDetail = new ScheduleFrequency(response.frequencyDetail);
    return response;
  },

  formatFrequencyDetail: function () {
    return this.get('frequencyDetail').formatDetail();
  },

  formatWeekDays: function () {
    return this.get('frequencyDetail').formatWeekDays();
  },

  toJSON: function () {
    var json = _.clone(this.attributes);
    _.each(json, function (value, key) {
      if (key === 'frequencyDetail' && json[key] !== '') {
        json[key] = json[key].toJSON();
      }
    });

    return json;
  },

  getEditUrl: function (externalResources) {
    var editUrlTemplate = this.get('editUrlTemplate');
    if (_.isNull(editUrlTemplate)) {
      return null;
    }

    var encodedReportName = encodeURIComponent(this.get('reportName'));

    return editUrlTemplate.replace("{portalBaseUrl}", externalResources.portalUrl).replace("{appBaseUrl}", externalResources.schedulingAppUrl)
      .replace("{reportingBaseUrl}", externalResources.reportingAppUrl).replace("{favoriteName}", encodedReportName)
      .replace("{externalId}", this.get('externalId'));
  }
});

module.exports = Schedule;
