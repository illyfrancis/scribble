var Backbone = require('backbone');

var UpcomingRuntime = Backbone.Model.extend({

  initialize: function () {
    this.fetched = false;
  },

  urlRoot: function () {
    var url = './api/schedules/{scheduleId}/upcomingruntimes';
    return url.replace('{scheduleId}', this.get('scheduleId'));
  },

  parse: function (response) {
    var runtime = (response.runtimes.length === 0 ? '' : response.runtimes[0]);
    return {
      'runtime': runtime
    };
  },

  next: function () {
    if (!this.fetched) {
      this.fetched = true;
      this.fetch({global: false});
    }
  }

});

module.exports = UpcomingRuntime;
