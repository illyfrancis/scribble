var Backbone = require('backbone');

// get authentication token
var authToken = 'none';
var tokens = document.cookie.match(/BBHid=(.*?)(;|$)/);
if (tokens && tokens[1]) {
  authToken = tokens[1];
}

// get user obj
var dashboard = global.dashboard || {};
dashboard.user = dashboard.user || {};

// set the auth token & user id in header for all ajax requests
Backbone.$.ajaxSetup({
  headers: {
    'X-Auth-Token': authToken,
    'X-User-Id': dashboard.user.id
  },
  cache: false
});

// loader
Backbone.$(document).ajaxStart(function () {
  Backbone.$('#loader').show();
}).ajaxStop(function () {
  Backbone.$('#loader').hide();
});

// enable tooltips
Backbone.$('body').tooltip({
  selector: '[data-toggle=tooltip]'
});

// sadly PUT & DELETE is not allowed...
Backbone.emulateHTTP = true;
