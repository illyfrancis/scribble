var TextFilter = require('./textFilter');
var template = require('./templates/reportNameFilter.html');

var ReportNameFilter = TextFilter.extend({

  template: function (attrs) {
    return template(attrs);
  }

});

module.exports = ReportNameFilter;
