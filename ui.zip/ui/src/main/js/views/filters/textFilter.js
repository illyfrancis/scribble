var _ = require('underscore');
var Backbone = require('backbone');

var TextFilter = Backbone.View.extend({

  events: {
    'blur input': 'copyFilterValue',
    'keydown input': 'clearError'
  },

  initialize: function () {
    this.listenTo(this.model, 'change:filter', this.render);
    this.listenTo(this.model, 'invalid', this.showError);
  },

  copyFilterValue: function () {
    var filter = this.$('input').val();
    this.model.setFilter(filter);
  },

  showError: function (model, error) {
    if (!this.$el.hasClass('has-error')) {
      this.$el.addClass('has-error');
      this.$('.help-block').removeClass('hidden');
      this.$('.help-block').text(error);
    }
  },

  clearError: function () {
    if (this.$el.hasClass('has-error')) {
      this.$el.removeClass('has-error');
      this.$('.help-block').addClass('hidden');
    }
  },

  render: function () {
    this.$el.html(this.template(_.defaults({'viewId': this.cid}, this.model.toJSON())));
    return this;
  },

  template: function () {
    return '';
  }

});

module.exports = TextFilter;
