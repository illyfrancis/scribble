var Backbone = require('backbone');
var template = require('./templates/dateRangeFilter.html');
var _ = require('underscore');

var DateRangeFilter = Backbone.View.extend({

  events: {
    'changeDate .date.from': 'changeFromDate',
    'changeDate .date.to': 'changeToDate',
    'change .date.from>input': 'changeFromDate',
    'change .date.to>input': 'changeToDate'
  },

  initialize: function () {
    this.listenTo(this.model, 'invalid', this.showError);
  },

  showError: function (model, error) {
    if (!this.$el.hasClass('has-error')) {
      this.$el.addClass('has-error');
      this.$('.help-block').removeClass('hidden');
      this.$('.help-block').text(error);
    }
  },

  clearError: function () {
    if (this.$el.hasClass('has-error')) {
      this.$el.removeClass('has-error');
      this.$('.help-block').addClass('hidden');
    }
  },

  changeFromDate: function () {
    this.clearError();
    var date = this.getDateFromField('.date.from');
    this.model.setFromDate(date);
    this.$('.date.to').datepicker('setStartDate', date);
  },

  changeToDate: function () {
    this.clearError();
    var date = this.getDateFromField('.date.to');
    this.model.setToDate(date);
    this.$('.date.from').datepicker('setEndDate', date);
  },

  getDateFromField: function (fieldSelector) {
    var date = this.$(fieldSelector).datepicker('getDate');
    return this.model.isValidDate(date) ? date : null;
  },

  render: function () {
    this.$el.html(
      template(_.defaults({
        'viewId': this.cid
      }, this.model.toJSON()))
    );
    var fromDate = this.$('.date.from');
    var toDate = this.$('.date.to');

    _.each([fromDate, toDate], function (item) {
      item.datepicker({
        format: "mm/dd/yyyy",
        multidate: false,
        autoclose: true,
        todayHighlight: true,
        clearBtn: true
      });
    });

    this.initializeDatePickers(fromDate, toDate);

    return this;
  },

  initializeDatePickers: function (fromDate, toDate) {
    if (this.model.isFilterSet()) {
      var filter = this.model.get('filter');
      fromDate.datepicker('update', filter.from);
      toDate.datepicker('update', filter.to);
    }
  },

  cleanup: function () {
    this.$('.date.from').datepicker('remove');
    this.$('.date.to').datepicker('remove');
  }
});

module.exports = DateRangeFilter;
