var TextFilter = require('./textFilter');
var template = require('./templates/userFilter.html');

var UserFilter = TextFilter.extend({

  template: function (attrs) {
    return template(attrs);
  }

});

module.exports = UserFilter;
