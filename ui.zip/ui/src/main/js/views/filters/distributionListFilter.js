var TextFilter = require('./textFilter');
var template = require('./templates/distributionListFilter.html');

var DistributionListFilter = TextFilter.extend({

  template: function (attrs) {
    return template(attrs);
  }

});

module.exports = DistributionListFilter;
