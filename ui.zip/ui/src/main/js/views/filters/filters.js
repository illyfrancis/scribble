var _ = require('underscore');
_.str = require('underscore.string');
var Backbone = require('backbone');
var FilterManager = require('./filterManager');
var template = require('./templates/filters.html');

var Filters = Backbone.View.extend({

  // this.collection is criteria

  className: 'filters',

  events: {
    'click .search': 'applyAndSearch',
    'click .cancel': 'cancelFilters',
    'hidden.bs.modal .modal': 'dispose',
  },

  initialize: function (options) {
    this.user = options.user;
  },

  render: function () {
    this.$el.html(template());

    var id, FilterView, filter;
    this.collection.each(function (criterion) {
      id = criterion.id;
      FilterView = FilterManager[id];

      if (!_.isUndefined(FilterView)) {
        filter = this.createSubView(FilterView, {
          model: criterion,
          el: this.$('.' + _.str.dasherize(id)),
          user: this.user
        });
        filter.render();
      }
    }, this);

    return this;
  },

  applyAndSearch: function () {
    if (this.hasNoErrors()) {
      Backbone.router.trigger('settings:update dashboard:search');
      this.$('.modal').modal('hide');
    }
  },

  cancelFilters: function () {
    this.$('.modal').modal('hide');
    this.collection.load();
  },

  hasNoErrors: function () {
    return this.$('.has-error').length === 0;
  }
});

module.exports = Filters;
