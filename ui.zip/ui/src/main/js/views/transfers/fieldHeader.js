var Backbone = require('backbone');
var template = require('./templates/fieldHeader.html');
var _ = require('underscore');
_.str = require('underscore.string');

var FieldHeader = Backbone.View.extend({

  tagName: 'th',

  className: function () {
    return _.str.dasherize(this.model.id) + (this.model.isSortable() ? ' sortable' : '');
  },

  events: {
    'click': 'setSortField'
  },

  initialize: function () {
    // this.model = criterion
    this.listenTo(this.model, 'change', this.render);
  },

  render: function () {
    this.$el.html(template(this.model.toJSON()));
    this.renderSortOrder();
    return this;
  },

  renderSortOrder: function () {
    this.updateClasses(this.model.isAscendingSort(), this.$el, 'dropup');
    this.updateClasses(this.model.isSortField(), this.$('.sort-order'), 'caret');
  },

  updateClasses: function (condition, selector, className) {
    if (condition) {
      selector.addClass(className);
    } else {
      selector.removeClass(className);
    }
  },

  setSortField: function () {
    if (this.model.isSortable()) {
      this.model.makeSortField();
    }
  }

});

module.exports = FieldHeader;
