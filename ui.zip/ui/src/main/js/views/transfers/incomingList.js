var _ = require('underscore');
var Backbone = require('backbone');
var ListHeader = require('./listHeader');
var TransferItem = require('./incomingItem');
var Transfers = require('../../collections/transfers');
var template = require('./templates/incomingList.html');

var IncomingList = Backbone.View.extend({

  className: '.table-responsive',

  initialize: function (options) {
    this.user = options.user;
    this.transfers = options.transfers;
    this.filteredTransferItems = new Transfers();

    this.listenTo(this.transfers.items, 'reset', this.filter);  // TODO - also listen for 'change' for when status is updated
    this.listenTo(this.transfers.filters, 'change', this.filter);
    this.listenTo(this.transfers.headers, 'change', this.sort);
    this.listenTo(this.filteredTransferItems, 'reset sort', this.render);
    // this.listenTo(this.filteredTransferItems, 'error', this.displayError);

    this.applyExistingSort();
  },

  filter: function () {
    var selectedStatuses = _.chain(this.transfers.filters.toJSON()).where({applied:true}).pluck('status');
    var filteredTransfers = this.transfers.items.filter(function (item) {
      var status = item.get('status');
      return selectedStatuses.contains(status).value();
    });

    this.filteredTransferItems.reset(filteredTransfers);
  },

  sort: function (header) {
    if (header.isSortField()) {
      this.filteredTransferItems.applySort(header.sortWith(), header.get('sortOrder'));
    }
  },

  applyExistingSort: function () {
    var sortField = this.transfers.headers.find(function (header) {
      return header.isSortField();
    });

    if (sortField) {
      this.sort(sortField);
    }
  },

  render: function () {
    this.disposeSubViews();
    this.$el.html(template());

    this.renderHeader();
    this.renderItems();

    return this;
  },

  renderHeader: function () {
    var listHeader = this.createSubView(ListHeader, {
      user: this.user,
      headers: this.transfers.headers
    });

    this.$('thead').append(listHeader.render().el);
  },

  renderItems: function () {
    if (this.filteredTransferItems.isEmpty()) {
      var message = this.transfers.items.isEmpty() ? 'There are no transfers.' : 'Transfers may be hidden by status filters.';
      this.$('tbody').append('<tr><td colspan="13">' + message + '</td></tr>');
    } else {
      this.filteredTransferItems.each(function (item) {
        this.appendTransferItem(item);
      }, this);
    }
  },

  appendTransferItem: function (item) {
    var transferItem = this.createSubView(TransferItem, {
      model: item,
      user: this.user
    });
    this.$('tbody').append(transferItem.render().el);
  }

});

module.exports = IncomingList;
