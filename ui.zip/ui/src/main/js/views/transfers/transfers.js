var Backbone = require('backbone');
var template = require('./templates/transfers.html');
var OutgoingList = require('./outgoingList');
var IncomingList = require('./incomingList');
var Menu = require('./menu');

var Transfers = Backbone.View.extend({

  className: 'transfers',

  initialize: function (options) {
    this.user = options.user;
    this.direction = options.direction;
    this.transfers = options.transfers;

    this.listenTo(Backbone.router, 'dashboard:transfers:search', this.loadTransfers);
  },

  loadTransfers: function (direction) {
    this.transfers.items.load();
  },

  render: function () {
    // this.disposeSubViews();  // needed?
    this.$el.html(template());
    this.renderMenu();
    this.renderList();

    this.loadTransfers();

    return this;
  },

  renderMenu: function () {
    var menu = this.createSubView(Menu, {
      direction: this.direction,
      filters: this.transfers.filters
    });

    this.$('.menu').replaceWith(menu.render().el);
  },

  renderList: function () {
    var TransferList = this.direction === 'incoming' ? IncomingList : OutgoingList;
    var transferList = this.createSubView(TransferList, {
      user: this.user,
      transfers: this.transfers
    });

    this.$('.collection').html(transferList.render().el);
  }

});

module.exports = Transfers;
