var _ = require('underscore');
var Backbone = require('backbone');
var moment = require('moment-timezone');
var template = require('./templates/incomingItem.html');

var IncomingItem = Backbone.View.extend({

  tagName: 'tr',

  events: {
    'click .accept': 'acceptTransfer',
    'click .reject': 'rejectTransfer'
  },

  initialize: function (options) {
    this.user = options.user;
    this.listenTo(this.model, 'sync', this.onSync);
    this.listenTo(this.model, 'error', this.onError);
  },

  onError: function (model, response, options) {
    console.log('> error : ' + JSON.stringify(model));
    var title = 'error';
    var message = 'general message';
    if (options.command === 'accept') {
      title = 'accept failed';
    } else if (options.command === 'reject') {
      title = 'reject failed';
    } else if (options.command === 'cancel') {
      title = 'cancel failed';
    }

    // TODO - parse?
    if (response.responseJSON) {
      message = JSON.stringify(response.responseJSON);
    }

    Backbone.router.trigger('dashboard:alert', {'title': title, 'message': message});
  },

  onSync: function (model, response, options) {
    console.log('on model sync : ' + JSON.stringify(model));
    // console.log('on model sync : ' + JSON.stringify(model) + ' : ' + JSON.stringify(response) + ' : ' + JSON.stringify(options));

    var message = 'general message';
    if (options.command === 'accept') {
      message = 'transfer accepted';
    } else if (options.command === 'reject') {
      message = 'transfer rejected';
    } else if (options.command === 'cancel') {
      message = 'transfer cancelled';
    }

    Backbone.router.trigger('dashboard:alert', {'title': 'Hello', 'message': message});
  },

  render: function () {
    this.$el.html(template(this.toJSON()));
    return this;
  },

  acceptTransfer: function () {
    var byUser = this.user.get('id');
    var transfer = this.model;

    Backbone.router.trigger('dashboard:confirm', {
      title: 'Accept Transfer',
      message: 'Continue?',
      onConfirm: function () {
        transfer.execute('accept', byUser);
      }
    });
  },

  rejectTransfer: function () {
    var byUser = this.user.get('id');
    var transfer = this.model;

    Backbone.router.trigger('dashboard:confirm', {
      title: 'Reject Transfer',
      message: 'Continue?',
      onConfirm: function () {
        transfer.execute('reject', byUser);
      }
    });
  },

  requestedOn: function () {
    var expiry = this.mapPropertyToMoment('requestedOn');
    return expiry.isValid() ? expiry.fromNow() : '';
  },

  requestExpiry: function () {
    var expiry = this.mapPropertyToMoment('requestExpiry');
    return expiry.isValid() ? expiry.fromNow() : '';
  },

  mapPropertyToMoment: function (property) {
    return this.mapPropertyToMomentUtc(this.model.get(property));
  },

  mapPropertyToMomentUtc: function (property) {
    return moment.tz(property, 'YYYY-MM-DDTHH:mm:ssZ', true, 'UTC');
  },

  transferSuccess: function () {
    var status = this.model.get('status');
    return status === 'ACCEPTED';
  },

  transferFailure: function () {
    var status = this.model.get('status');
    return status === 'REJECTED' || status === 'EXPIRED' || status === 'CANCELLED';
  },

  transferPending: function () {
    var status = this.model.get('status');
    return status === 'PENDING';
  },

  toJSON: function () {
    return _.defaults({
      'requestedOn': this.requestedOn(),
      'requestExpiry': this.requestExpiry(),
      'transferSuccess': this.transferSuccess(),
      'transferFailure': this.transferFailure(),
      'transferPending': this.transferPending(),
    }, this.model.toJSON());
  },


});

module.exports = IncomingItem;



