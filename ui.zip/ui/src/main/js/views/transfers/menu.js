var Backbone = require('backbone');
var _ = require('underscore');
var template = require('./templates/menu.html');
var StatusFilter = require('./statusFilter');

var Menu = Backbone.View.extend({

  className: 'menu',

  events: {
	  'click .search': 'searchTransfers'
  },

  initialize: function (options) {
    this.direction = options.direction;
    this.filters = options.filters;
  },

  render: function () {
    this.$el.html(template());

    this.filters.each(function (item) {
      var statusFilter = this.createSubView(StatusFilter, {
        model: item
      });

      this.$('.toolbar').append(statusFilter.render().el);
    }, this);

    return this;
  },

  searchTransfers: function () {
    Backbone.router.trigger('dashboard:transfers:search', this.direction);
  }

});

module.exports = Menu;
