var Backbone = require('backbone');
var template = require('./templates/outgoingItem.html');

var OutgoingItem = Backbone.View.extend({

  tagName: 'tr',

  initialize: function (options) {
    this.user = options.user;
  },

  render: function () {
    this.$el.html(template(this.model.toJSON()));
    return this;
  }
});

module.exports = OutgoingItem;
