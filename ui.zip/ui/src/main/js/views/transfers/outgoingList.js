/*global alert*/
var Backbone = require('backbone');
// var ScheduleHeader = require('./scheduleHeader');
var TransferItem = require('./outgoingItem');
var template = require('./templates/outgoingList.html');

var OutgoingList = Backbone.View.extend({

  className: '.table-responsive',

  initialize: function (options) {
    // this.collection = transfers collection
    this.user = options.user;
    this.collection = options.transfers.items;
    this.listenTo(this.collection, 'reset', this.render);
    // this.listenTo(this.collection, 'error', this.displayError);
  },

  displayError: function () {
    alert('Error');
  },

  render: function () {
    this.disposeSubViews();
    this.$el.html(template());

    // this.renderHeader();
    this.renderItems();

    return this;
  },

  // renderHeader: function () {
  //   var scheduleHeader = this.createSubView(ScheduleHeader, {
  //     collection: this.criteria,
  //     user: this.user
  //   });

  //   this.$('thead').append(scheduleHeader.render().el);
  // },

  renderItems: function () {
    if (this.collection.isEmpty()) {
      // TODO - clean up
      this.$('tbody').append('<tr><td colspan="13">no transfers found</td></tr>');
    } else {
      this.collection.each(function (item) {
        this.appendTransferItem(item);
      }, this);
    }
  },

  appendTransferItem: function (item) {
    var transferItem = this.createSubView(TransferItem, {
      model: item,
      user: this.user
    });
    this.$('tbody').append(transferItem.render().el);
  }

});

module.exports = OutgoingList;
