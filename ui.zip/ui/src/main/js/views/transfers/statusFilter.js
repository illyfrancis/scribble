var Backbone = require('backbone');
var _ = require('underscore');
_.str = require('underscore.string');
var template = require('./templates/statusFilter.html');

var StatusFilter = Backbone.View.extend({

  attributes: {
    'class': 'btn-group',
    'data-toggle': 'buttons'
  },

  events: {
    'click': 'toggle'
  },

  render: function () {
    this.$el.html(template(this.toJSON()));
    return this;
  },

  toJSON: function () {
    return _.defaults({
      'status': _.str.titleize(this.model.get('status'))
    }, this.model.toJSON());
  },

  toggle: function () {
    var applied = this.model.get('applied');
    this.model.set('applied', !applied);
  }

});

module.exports = StatusFilter;
