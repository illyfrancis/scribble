var Backbone = require('backbone');
var FieldHeader = require('./fieldHeader');

var ListHeader = Backbone.View.extend({

  tagName: 'tr',

  initialize: function (options) {
    this.user = options.user;
    this.headers = options.headers;
  },

  render: function () {
    this.headers.each(this.appendHeader, this);
    return this;
  },

  appendHeader: function (field) {
    var fieldHeader = this.createSubView(FieldHeader, {
      model: field
    });
    this.$el.append(fieldHeader.render().el);
  }

});

module.exports = ListHeader;
