var Backbone = require('backbone');
var template = require('./templates/confirmation.html');

var Confirmation = Backbone.View.extend({

  events: {
    'click .exit': 'exit',
    'click .confirm': 'confirm',
    // dispose when css transition completes, - refer to doc for detail
    'hidden.bs.modal': 'dispose'
  },

  initialize: function (options) {
    // TODO - title, message and callback need to be provided, validate
    this.title = options.title;
    this.message = options.message;
    if (options.onConfirm) {
      this.onConfirm = options.onConfirm;
    }
  },

  render: function () {
    this.$el.html(template({title: this.title,
      message: this.message,
      isConfirm: !!this.onConfirm
    }));
    return this;
  },

  confirm: function () {
    this.onConfirm && this.onConfirm();
    this.exit();
  },

  show: function () {
    this.$('.confirmation').modal('show');
  },

  exit: function () {
    this.$('.confirmation').modal('hide');
  }
});

module.exports = Confirmation;
