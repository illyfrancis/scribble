var Backbone = require('backbone');
var Errors = require('./errors');
var Loader = require('./loader');
var Notification = require('./notification');
var Schedules = require('../schedules/schedules');
var SchedulesMenu = require('../schedules/menu');
var Transfers = require('../transfers/transfers');
var template = require('./templates/dashboard.html');

var DashboardView = Backbone.View.extend({

  className: 'dashboard container-fluid',

  initialize: function (options) {
    this.user = options.user;
    this.criteria = options.criteria;
    this.schedules = options.schedules;
    this.transfers = options.transfers;
    this.listenTo(Backbone.router, 'dashboard:notify', this.showNotification);
  },

  render: function () {
    this.disposeSubViews();
    this.$el.html(template());

    this.renderLoader();
    this.renderErrors();

    return this;
  },

  showNotification: function (text, type) {
    var notification = this.createSubView(Notification, {
      text: text,
      type: type
    });
    this.$el.append(notification.render().el);
  },

  showSchedules: function () {
    this.disposeSubViews();
    var menu = this.createSubView(SchedulesMenu, {
      criteria: this.criteria,
      user: this.user
    });

    var schedules = this.createSubView(Schedules, {
      collection: this.schedules,
      criteria: this.criteria,
      user: this.user
    });

    this.$('.dashboard-nav a[href="#schedules"]').tab('show');
    this.$('.dashboard-content').empty().append(menu.render().el).append(schedules.render().el);
  },

  showTransfers: function (direction) {
    if (direction) {
      this.disposeSubViews();

      var transfersView = this.createSubView(Transfers, {
        user: this.user,
        direction: direction,
        transfers: this.transfers[direction]
      });

      this.$('.dashboard-nav a[href="#transfers/' + direction + '"]').tab('show');
      this.$('.dashboard-content').empty().append(transfersView.render().el);
    }
  },

  renderLoader: function () {
    var loader = new Loader();
    this.$el.append(loader.render().el);
  },

  renderErrors: function () {
    // this.createSubView(Errors);   // TODO - check this. how about new Errors()?
    new Errors();
  }
});

module.exports = DashboardView;
