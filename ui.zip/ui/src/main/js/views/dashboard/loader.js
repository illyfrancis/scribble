var Backbone = require('backbone');
var template = require('./templates/loader.html');

var Loader = Backbone.View.extend({

  id: 'loader',

  className: 'loader',

  render: function () {
    this.$el.html(template());
    return this;
  }
});

module.exports = Loader;
