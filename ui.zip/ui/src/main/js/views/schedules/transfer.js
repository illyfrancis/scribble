/* global Bloodhound */
var _ = require('underscore');
var Backbone = require('backbone');
var Action = require('../../models/action');
var template = require('./templates/transfer.html');
var emptyTemplate = require('../templates/emptySuggestion.html');
var userTemplate = require('../templates/userSuggestion.html');

var Transfer = Backbone.View.extend({

  events: {
    'click .ok': 'transfer',
    'click .exit': 'exit',
    // dispose when css transition completes, - refer to doc for detail
    'hidden.bs.modal': 'dispose',
    'typeahead:selected': 'addSelectedUser'
  },

  initialize: function (options) {
    this.action = new Action();
    this.model = options.model;

    this.initializeTypeaheadEngine();
  },

  initializeTypeaheadEngine: function () {
    this.hound = new Bloodhound({
      // TODO - figure out exactly how to configure this
      datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
      queryTokenizer: Bloodhound.tokenizers.whitespace,
      limit: 250, // TODO increase limit dynamically
      remote: {
        url: './api/users/search?q=%QUERY'
      }
    });

    this.hound.initialize();
  },

  render: function () {
    this.$el.html(template({
      'viewId': this.cid
    }));

    this.typeahead();
    return this;
  },

  typeahead: function () {
    this.$('.typeahead').typeahead({
      hint: true,
      highlight: true,
      minLength: 3
    }, {
      name: 'users',
      displayKey: function (user) {
        return user.id;
      },
      source: this.hound.ttAdapter(),
      templates: {
        empty: emptyTemplate(),
        suggestion: userTemplate
      }
    });
  },

  transfer: function () {
    var destinationUserId = 101;
    this.action.initiateTransfer(this.model.id, destinationUserId);
    this.exit();
  },

  show: function () {
    this.$('.transfer').modal('show');
  },

  exit: function () {
    this.$('.transfer').modal('hide');
  },

  addSelectedUser: function (event, suggestion) {
    this.user = _.clone(suggestion);
    // this.users.add(suggestion);
    // this.$('.typeahead').typeahead('val', '');
  },

  cleanup: function () {
    this.$('.typeahead').typeahead('destroy');
  }
});

module.exports = Transfer;
