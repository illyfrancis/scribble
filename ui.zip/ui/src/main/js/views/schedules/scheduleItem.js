var _ = require('underscore');
var Backbone = require('backbone');
var moment = require('moment-timezone');
var template = require('./templates/scheduleItem.html');
var scheduleFrequencyTemplate = require('./templates/scheduleFrequency.html');
var UpcomingRuntime = require('../../models/upcomingRuntime');

var ScheduleItem = Backbone.View.extend({

  tagName: 'tr',

  events: {
    'click': 'toggleDetail'
  },

  initialize: function (options) {
    this.user = options.user;
    this.upcomingRuntime = new UpcomingRuntime({
      scheduleId: this.model.get('id')
    });
    this.listenTo(this.upcomingRuntime, 'change', this.updateNextRuntime);
  },

  toggleDetail: function () {
    var detailName = '.detail' + this.model.id;
    var p = this.$el.parent();
    p.find('.collapse.in').not(detailName).collapse('hide');
    p.find(detailName).collapse('toggle');
  },

  render: function () {
    this.$el.html(template(this.toJSON()));

    // create tooltip for frequency
    var self = this;
    this.$('.frequency .label-default').tooltip({
      placement: 'auto top',
      html: true,
      title: this.frequencyDetail(self)
    });

    return this;
  },

  cleanup: function () {
    this.$('[data-toggle=tooltip]').tooltip('destroy');
    this.$('.frequency .label-default').tooltip('destroy');
  },

  updateNextRuntime: function (upcomingRuntime) {
    var shown = this.$('.frequency .tooltip').length;
    if (shown) {
      var runtime = upcomingRuntime.get('runtime');
      var nextRuntime = this.mapUpcomingRuntime(runtime);
      // this isn't the best - position doesn't change dynamically but works
      this.$('.frequency .tooltip-inner').html(this.frequencyDetailHtml(this.model, nextRuntime));
    }
  },

  frequencyDetail: function (self) {
    return function () {
      var runtime = self.upcomingRuntime.get('runtime');
      if (_.isUndefined(runtime)) {
        self.upcomingRuntime.next();
      }

      var nextRuntime = self.mapUpcomingRuntime(runtime);
      return self.frequencyDetailHtml(self.model, nextRuntime);
    };
  },

  frequencyDetailHtml: function (schedule, nextRuntime) {
    return scheduleFrequencyTemplate({
      'details': schedule.formatFrequencyDetail(),
      'timezone': schedule.get('timezoneCode'),
      'runtime': nextRuntime
    });
  },

  mapPropertyToMoment: function (property) {
    return this.mapPropertyToMomentUtc(this.model.get(property));
  },

  mapPropertyToMomentUtc: function (property) {
    return moment.tz(property, 'YYYY-MM-DDTHH:mm:ssZ', true, 'UTC');
  },

  mapUpcomingRuntime: function (dateTime) {
    // if we return undefined, null or '', ellipses (...) will be displayed
    if (dateTime === '') {
      return ' ';
    }

    var dateTimeUtc = this.mapPropertyToMomentUtc(dateTime);
    return dateTimeUtc.isValid() ? dateTimeUtc.tz(this.user.get('timezone')).format('DD-MMM-YYYY h:mma') : '';
  },

  mapLastExecution: function () {
    var executedAt = this.mapPropertyToMoment('lastExecution');
    return executedAt.isValid() ? executedAt.fromNow() : '';
  },

  lastExecutionAsTooltip: function () {
    var executedAt = this.mapPropertyToMoment('lastExecution');
    return executedAt.isValid() ? executedAt.tz(this.user.get('timezone')).format('DD-MMM-YYYY h:mm:ssa') : '';
  },

  mapReportExpiry: function () {
    var expiresAt = this.mapPropertyToMoment('reportExpiry');
    return expiresAt.isValid() ? expiresAt.tz(this.user.get('timezone')).format('MMM Do YYYY') : 'No expiry';
  },

  reportExpiryAsTooltip: function () {
    var expiresAt = this.mapPropertyToMoment('reportExpiry');
    return expiresAt.isValid() ? 'At ' + expiresAt.tz(this.user.get('timezone')).format('h:mm:ssa') : '';
  },

  mapDistributionFormat: function () {
    var distributionFormat = this.model.get('distributionFormat');
    return _.map(distributionFormat, function (item) {
      var mapped = {
        'delivery': item
      };
      mapped[item] = true;
      return mapped;
    });
  },

  toJSON: function () {
    return _.defaults({
      'timeago': this.mapLastExecution(),
      'lastExecutionAsTooltip': this.lastExecutionAsTooltip(),
      'expiry': this.mapReportExpiry(),
      'expiryAsTooltip': this.reportExpiryAsTooltip(),
      'deliveryOptions': this.mapDistributionFormat(),
      'weekDays': this.model.formatWeekDays(),
    }, this.model.toJSON());
  }
});

module.exports = ScheduleItem;
