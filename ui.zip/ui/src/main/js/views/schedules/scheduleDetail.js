/*global window*/
var _ = require('underscore');
var Action = require('../../models/action');
var Backbone = require('backbone');
var Confirmation = require('../dashboard/confirmation');
var Downloader = require('./downloader');
var Transfer = require('./transfer');
var runMessageTemplate = require('./templates/runConfirmation.html');
var template = require('./templates/scheduleDetail.html');

var ScheduleDetail = Backbone.View.extend({

  tagName: 'tr',

  events: {
    'click .run-schedule': 'runSchedule',
    'click .edit-schedule': 'editSchedule',
    'click .download' : 'downloadReport',
    'click .transfer' : 'transfer'
  },

  initialize: function (options) {
    this.user = options.user;
  },

  render: function () {
    this.$el.html(template(
      _.defaults({
        'isEditEnabled': this.isEditEnabled(),
        'isRunNowEnabled': this.isRunNowEnabled()
      }, this.model.toJSON())
    ));

    // activate 'collapse' for IE
    this.$el.collapse({toggle: false});
    this.$('.detail' + this.model.id).collapse({toggle: false});

    return this;
  },

  isEditEnabled: function () {
    return (this.isReportOwnedByUser()) && (!_.isNull(this.model.get('editUrlTemplate')));
  },

  isRunNowEnabled: function () {
    return this.isReportOwnedByUser();
  },

  isReportOwnedByUser: function () {
    return this.model.get('reportOwnerId') === this.user.id;
  },

  runSchedule: function () {

    var schedulerId = this.model.id;
    var executeSchedule = function () {
      var action = new Action();
      action.runSchedule(schedulerId);
    };

    var confirmationDialog = this.createSubView(Confirmation, {
      title: 'Report Generation',
      message: runMessageTemplate({
        'scheduleName': this.model.get('reportName')
      }),
      onConfirm: executeSchedule
    });
    this.addToParent(confirmationDialog);
  },

  addToParent: function (subView, showParam) {
    var parents = this.$el.parents('div');
    if (parents.length > 0) {
      subView.render().$el.appendTo(parents[0]);
      subView.show(showParam);
    }
  },

  getEditUrl: function () {
    return this.model.getEditUrl(this.user.get('externalResources'));
  },

  editSchedule: function () {
    window.top.location = this.getEditUrl();
  },

  downloadReport: function () {
    if (this.downloader) {
      this.downloader.dispose();
    }

    if(this.reportOutputExists()) {
      this.downloader = this.createSubView(Downloader, {
        outputId : this.model.get('lastReportOutputId')
      });

      this.$el.append(this.downloader.render().el);
    } else {
      Backbone.router.trigger('dashboard:notify', "Last executed report is not available for download.", 'warning');
    }
  },

  reportOutputExists: function () {
    return this.model.get('lastReportOutputId') !== 0;
  },

  transfer: function () {
    var transferDialog = this.createSubView(Transfer, {
      model: this.model
    });
    this.addToParent(transferDialog);
  }
});

module.exports = ScheduleDetail;
