var _ = require('underscore');
var Backbone = require('backbone');
var Confirmation = require('./views/dashboard/confirmation');
var Dashboard = require('./views/dashboard/dashboard');
var Filters = require('./views/filters/filters');
var Query = require('./models/query');
var repository = require('./repository');

var AppRouter = Backbone.Router.extend({

  routes: {
    '': 'showSchedules',
    'schedules': 'showSchedules',
    'transfers(/:direction)': 'showTransfers'
  },

  initialize: function () {
    this.listenTo(this, 'dashboard:search', this.search);
    this.listenTo(this, 'settings:update', this.updateCriteria);
    this.listenTo(this, 'dashboard:alert', this.showAlert);
    this.listenTo(this, 'dashboard:confirm', this.confirm);
  },

  search: function (page) {
    page = _.isUndefined(page) ? 1 : page;
    new Query().search(page);
  },

  updateCriteria: function () {
    repository.criteria().save();
  },

  showAlert: function (options) {
    console.log('alert with : ' + JSON.stringify(options));

    var confirmationDialog = new Confirmation(options);
    confirmationDialog.render().$el.appendTo(Backbone.$('.dashboard-container'));
    confirmationDialog.show();
  },

  confirm: function (options) {
    console.log('confirm with : ' + JSON.stringify(options));

    var confirmationDialog = new Confirmation(options);
    confirmationDialog.render().$el.appendTo(Backbone.$('.dashboard-container'));
    confirmationDialog.show();
  },

  showSchedules: function () {
    this.dashboard().showSchedules();
  },

  showTransfers: function (direction) {
    this.dashboard().showTransfers(direction);
  },

  dashboard: function () {
    if (!this.dashboardView) {
      this.dashboardView = new Dashboard({
        user: repository.user(),
        criteria: repository.criteria(),
        schedules: repository.schedules(),
        transfers: repository.transfers()
      });

      Backbone.$('.dashboard-container').empty().append(this.dashboardView.render().el);
    }

    return this.dashboardView;
  },

  showFilters: function () {
    var filters = new Filters({
      user: repository.user(),
      collection: repository.criteria()
    });

    // TODO - attach the filter to div.schedules so that it can be disposed when routes to #transfers from #schedules (although this may not occur in real scenario)
    Backbone.$('.dashboard-container').append(filters.render().el);
    filters.$('.modal').modal('show');
  }
});

module.exports = AppRouter;
