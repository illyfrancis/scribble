var _ = require('underscore');
var Backbone = require('backbone');
var Clients = require('./collections/clients');
var Criteria = require('./collections/criteria');
var Criterion = require('./models/criteria/criterion');
var Schedules = require('./collections/schedules');
var Settings = require('./collections/settings');
var Transfers = require('./collections/transfers');
var User = require('./models/user');

var Repository = {

  user: _.once(function () {
    var dashboard = global.dashboard || {};
    dashboard.user = dashboard.user || {};
    dashboard.externalResources = dashboard.externalResources || {};
    var dashboardUser = new User(dashboard.user);
    dashboardUser.setExternalResources(dashboard.externalResources);
    return dashboardUser;
  }),

  clients: _.once(function () {
    return new Clients();
  }),

  loadClients: function () {
    return this.clients().fetch({
      reset: true
    });
  },

  criteria: _.once(function () {
    return new Criteria();
  }),

  loadCriteria: function () {
    return this.criteria().load();
  },

  schedules: _.once(function () {
    return new Schedules();
  }),

  loadSchedules: function () {
    Backbone.router.trigger('dashboard:search');
  },

  transfers: _.once(function () {
    var userId = this.user().get('id');
    var defaultFilters = Settings.transfers.defaultFilters();

    return {
      outgoing: {
        items: new Transfers([], {userId: userId, direction: 'outgoing'}),
        filters: new Backbone.Collection(defaultFilters),
        headers: new Backbone.Collection(Settings.transfers.outgoingHeaders(), { model: Criterion })
      },

      incoming: {
        items: new Transfers([], {userId: userId, direction: 'incoming'}),
        filters: new Backbone.Collection(defaultFilters),
        headers: new Backbone.Collection(Settings.transfers.incomingHeaders(), { model: Criterion })
      }
    };
  })

};

module.exports = Repository;

