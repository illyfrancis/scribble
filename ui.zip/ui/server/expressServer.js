var express = require('express');
var app = express();

// app.get('/schedulerdashboard', function (req, res) {
//   res.send('Hello world');
// });

app.use('/schedulerdashboard/app', express.static('../target/index.html'));
app.use('/schedulerdashboard', express.static('../target'));

var server = app.listen(3000, function () {

  var host = server.address().address;
  var port = server.address().port;

  console.log('Example at http://%s:%s', host, port);
});

var http = require('http'),
    httpProxy = require('http-proxy');

var proxy = httpProxy.createServer();
proxy.on('error', function (err, req, res) {
  res.writeHead(500, {
    'Content-Type': 'text/plain'
  });

  console.log('  --> error ' + req.url);
  res.end('Server not responding.');
});

var router = function(req, res) {
  if (req.url.indexOf('/api') > -1 || req.url.indexOf('/reportoutput') > -1) {
    console.log(req.url + ' -> localhost:3002');
    proxy.web(req, res, {
      target: 'http://localhost:3002'
    });
  } else {
    console.log(req.url + ' -> localhost:3000');
    proxy.web(req, res, {
      target: 'http://localhost:3000'
    });
  }
};

http.createServer(router).listen(3001);
